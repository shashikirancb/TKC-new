"""Backend API tests for The Kalyan Chronicles."""
import os
import time
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://telugu-chronicles.preview.emergentagent.com").rstrip("/")
ADMIN_EMAIL = "shashikirancb@gmail.com"
ADMIN_PASSWORD = "Kalyan@2026"


@pytest.fixture(scope="session")
def api():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


@pytest.fixture(scope="session")
def token(api):
    r = api.post(f"{BASE_URL}/api/auth/login",
                 json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert r.status_code == 200, f"Login failed: {r.status_code} {r.text}"
    data = r.json()
    assert "access_token" in data and data["user"]["role"] == "owner"
    return data["access_token"]


@pytest.fixture(scope="session")
def admin(api, token):
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json", "Authorization": f"Bearer {token}"})
    return s


# ---------------- Public ----------------
class TestPublic:
    def test_settings(self, api):
        r = api.get(f"{BASE_URL}/api/settings")
        assert r.status_code == 200
        d = r.json()
        assert d["site_name"] == "The Kalyan Chronicles"
        assert "epaper_url" in d and "topics" in d

    def test_guests_list(self, api):
        r = api.get(f"{BASE_URL}/api/guests")
        assert r.status_code == 200
        d = r.json()
        assert "items" in d and "total" in d
        assert d["total"] >= 5
        # Only published should surface
        for g in d["items"]:
            assert g.get("status") == "published"
            assert "_id" not in g
            assert g.get("video_id")

    def test_guests_search_and_sort(self, api):
        r = api.get(f"{BASE_URL}/api/guests?q=Srinivas")
        assert r.status_code == 200
        items = r.json()["items"]
        assert any("Srinivas" in g["name"] for g in items)
        r = api.get(f"{BASE_URL}/api/guests?sort=az&limit=20")
        names = [g["name"] for g in r.json()["items"]]
        assert names == sorted(names)

    def test_guests_topic_filter(self, api):
        r = api.get(f"{BASE_URL}/api/guests?topic=Technology")
        assert r.status_code == 200
        for g in r.json()["items"]:
            assert g["topic"] == "Technology"

    def test_latest_pinned(self, api):
        r = api.get(f"{BASE_URL}/api/guests/latest")
        assert r.status_code == 200
        g = r.json()
        assert g is not None
        assert g["name"] == "Dr. K. Srinivas"
        assert g.get("pinned") is True

    def test_featured(self, api):
        r = api.get(f"{BASE_URL}/api/guests/featured")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_guest_detail_with_related(self, api):
        slug = api.get(f"{BASE_URL}/api/guests").json()["items"][0]["slug"]
        r = api.get(f"{BASE_URL}/api/guests/{slug}")
        assert r.status_code == 200
        d = r.json()
        assert d["slug"] == slug
        assert "related" in d and isinstance(d["related"], list)

    def test_guest_detail_404(self, api):
        r = api.get(f"{BASE_URL}/api/guests/does-not-exist-xyz")
        assert r.status_code == 404

    def test_home_top_ad(self, api):
        r = api.get(f"{BASE_URL}/api/ads/home-top")
        assert r.status_code == 200
        ad = r.json()
        assert ad is not None
        assert ad["advertiser"] == "Shine Studios"
        assert "_id" not in ad

    def test_ad_impression(self, api):
        ad = api.get(f"{BASE_URL}/api/ads/home-top").json()
        r = api.post(f"{BASE_URL}/api/ads/{ad['id']}/impression")
        assert r.status_code == 200 and r.json()["ok"]

    def test_event_tracking(self, api):
        for t in ["click_youtube", "click_epaper", "click_advertise"]:
            r = api.post(f"{BASE_URL}/api/events", json={"type": t, "video_id": "abc"})
            assert r.status_code == 200

    def test_application_requires_consent(self, api):
        r = api.post(f"{BASE_URL}/api/applications", json={
            "name": "TEST_User", "email": "test_app@example.com", "consent": False})
        assert r.status_code == 400

    def test_application_submit(self, api):
        r = api.post(f"{BASE_URL}/api/applications", json={
            "name": "TEST_Applicant", "email": "test_applicant@example.com",
            "consent": True, "expertise": "Testing", "bio": "QA",
            "profession": "SDET", "organisation": "QA Co"})
        assert r.status_code == 200
        assert r.json()["ok"] is True

    def test_application_honeypot_dropped(self, api):
        r = api.post(f"{BASE_URL}/api/applications", json={
            "name": "bot", "email": "bot@example.com", "consent": True, "honeypot": "spam"})
        # Should silently return ok without actually inserting
        assert r.status_code == 200

    def test_newsletter_requires_consent(self, api):
        r = api.post(f"{BASE_URL}/api/newsletter/subscribe",
                     json={"email": "nn@example.com", "consent": False})
        assert r.status_code == 400

    def test_newsletter_subscribe(self, api):
        r = api.post(f"{BASE_URL}/api/newsletter/subscribe",
                     json={"email": f"test_sub_{int(time.time())}@example.com",
                           "consent": True, "name": "T"})
        assert r.status_code == 200
        assert "message" in r.json()

    def test_ad_inquiry(self, api):
        r = api.post(f"{BASE_URL}/api/ad-inquiries", json={
            "company": "TEST_Co", "contact_name": "Tester",
            "email": "test_adinq@example.com", "budget": "10k",
            "ad_type": "banner", "message": "hi"})
        assert r.status_code == 200
        assert r.json()["ok"] is True


# ---------------- Auth ----------------
class TestAuth:
    def test_login_bad(self, api):
        r = api.post(f"{BASE_URL}/api/auth/login",
                     json={"email": ADMIN_EMAIL, "password": "wrong"})
        assert r.status_code == 401

    def test_me_requires_auth(self, api):
        r = api.get(f"{BASE_URL}/api/auth/me")
        assert r.status_code == 401

    def test_me_ok(self, admin):
        r = admin.get(f"{BASE_URL}/api/auth/me")
        assert r.status_code == 200
        assert r.json()["email"] == ADMIN_EMAIL


# ---------------- Admin ----------------
class TestAdmin:
    def test_dashboard(self, admin):
        r = admin.get(f"{BASE_URL}/api/admin/dashboard")
        assert r.status_code == 200
        d = r.json()
        for k in ("totals", "clicks_week", "top_guests", "latest_applications"):
            assert k in d
        assert d["totals"]["guests"] >= 6

    def test_admin_guests_lists_drafts(self, admin):
        r = admin.get(f"{BASE_URL}/api/admin/guests")
        assert r.status_code == 200
        guests = r.json()
        assert any(g.get("status") == "draft" for g in guests), "Should include draft Suresh Babu"

    def test_guest_crud_and_translate_flow(self, admin):
        # Create with invalid YouTube URL -> 400
        bad = admin.post(f"{BASE_URL}/api/admin/guests", json={
            "name": "TEST_Bad", "youtube_url": "https://example.com/not-youtube"})
        assert bad.status_code == 400

        # Create valid
        create = admin.post(f"{BASE_URL}/api/admin/guests", json={
            "name": "TEST_Guest", "topic": "Technology",
            "youtube_url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            "title_en": "T", "synopsis_en": "S", "status": "draft"})
        assert create.status_code == 200
        gid = create.json()["id"]
        slug = create.json()["slug"]
        assert create.json()["video_id"] == "dQw4w9WgXcQ"

        # Not visible publicly (draft)
        assert admin.get(f"{BASE_URL}/api/guests/{slug}").status_code == 404

        # Update to published
        up = admin.put(f"{BASE_URL}/api/admin/guests/{gid}", json={
            "name": "TEST_Guest", "topic": "Technology",
            "youtube_url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            "title_en": "T", "synopsis_en": "S", "status": "published"})
        assert up.status_code == 200

        # Now visible
        pub = admin.get(f"{BASE_URL}/api/guests/{slug}")
        assert pub.status_code == 200

        # Duplicate
        dup = admin.post(f"{BASE_URL}/api/admin/guests/{gid}/duplicate")
        assert dup.status_code == 200
        dup_id = dup.json()["id"]
        assert "(Copy)" in dup.json()["name"]

        # Bulk delete
        bulk = admin.post(f"{BASE_URL}/api/admin/guests/bulk",
                          json={"ids": [gid, dup_id], "action": "delete"})
        assert bulk.status_code == 200

    def test_translate(self, admin):
        r = admin.post(f"{BASE_URL}/api/admin/translate",
                       json={"title_en": "Hello World", "synopsis_en": "A short podcast about tech."})
        assert r.status_code == 200, f"translate failed: {r.text}"
        d = r.json()
        assert "title_te" in d and "synopsis_te" in d
        # Expect at least some content
        assert (d["title_te"] + d["synopsis_te"]).strip() != ""

    def test_applications_inbox(self, admin):
        r = admin.get(f"{BASE_URL}/api/admin/applications")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_subscribers_list(self, admin):
        r = admin.get(f"{BASE_URL}/api/admin/subscribers")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_ads_crud(self, admin):
        c = admin.post(f"{BASE_URL}/api/admin/ads", json={
            "advertiser": "TEST_Ad", "headline": "H", "image_url": "https://x/y.jpg",
            "destination_url": "https://x", "slots": ["home-top"], "status": "active",
            "priority": 1, "language": "all"})
        assert c.status_code == 200
        aid = c.json()["id"]
        rep = admin.get(f"{BASE_URL}/api/admin/ads/{aid}/report")
        assert rep.status_code == 200
        assert "ad" in rep.json() and "daily" in rep.json()
        d = admin.delete(f"{BASE_URL}/api/admin/ads/{aid}")
        assert d.status_code == 200

    def test_ad_inquiries_admin(self, admin):
        r = admin.get(f"{BASE_URL}/api/admin/ad-inquiries")
        assert r.status_code == 200

    def test_settings_update_epaper(self, admin):
        new_url = "https://example.com/epaper-test"
        r = admin.put(f"{BASE_URL}/api/admin/settings", json={"epaper_url": new_url})
        assert r.status_code == 200
        # verify persisted
        s = requests.get(f"{BASE_URL}/api/settings").json()
        assert s["epaper_url"] == new_url
        # reset to empty for "Coming soon" acceptance behavior
        admin.put(f"{BASE_URL}/api/admin/settings", json={"epaper_url": ""})

    def test_admin_requires_auth(self, api):
        r = api.get(f"{BASE_URL}/api/admin/dashboard")
        assert r.status_code == 401
