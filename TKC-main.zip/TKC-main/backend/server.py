from dotenv import load_dotenv
from pathlib import Path
import os

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

from fastapi import FastAPI, APIRouter, HTTPException, Request, Depends, Query, UploadFile, File, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime, timezone, timedelta
import logging, uuid, re, secrets, bcrypt, jwt, httpx, ipaddress, requests
from html import escape
from html.parser import HTMLParser
from urllib.parse import urlparse

# ---------------------------------------------------------------------------
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

JWT_SECRET = os.environ['JWT_SECRET']
JWT_ALG = "HS256"
ACCESS_TTL_MIN = 480  # 8h session timeout
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY', '')
EMAIL_BASE_URL = "https://integrations.emergentagent.com"
EMAIL_KEY = os.environ.get('EMERGENT_EMAIL_KEY', '')
EMAIL_FROM_NAME = os.environ.get('EMAIL_FROM_NAME', 'The Kalyan Chronicles')
EMAIL_REPLY_TO = os.environ.get('EMAIL_REPLY_TO')
PUBLIC_URL = os.environ.get('PUBLIC_URL', '').rstrip('/')

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = FastAPI()
api = APIRouter(prefix="/api")

now = lambda: datetime.now(timezone.utc)
def iso(): return now().isoformat()
def new_id(): return str(uuid.uuid4())

# ---------------------- Object storage ------------------------------------
STORAGE_BASE = (os.environ.get("INTEGRATION_PROXY_URL") or "").strip() or "https://integrations.emergentagent.com"
STORAGE_URL = STORAGE_BASE.rstrip("/") + "/objstore/api/v1/storage"
APP_NAME = "kalyan-chronicles"
MIME = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp", "gif": "image/gif"}
_storage_key = None

def init_storage(force=False):
    global _storage_key
    if _storage_key and not force:
        return _storage_key
    resp = requests.post(f"{STORAGE_URL}/init", json={"emergent_key": EMERGENT_LLM_KEY}, timeout=30)
    resp.raise_for_status()
    _storage_key = resp.json()["storage_key"]
    return _storage_key

def put_object(path, data, content_type):
    key = init_storage()
    resp = requests.put(f"{STORAGE_URL}/objects/{path}", headers={"X-Storage-Key": key, "Content-Type": content_type}, data=data, timeout=120)
    if resp.status_code == 404:
        key = init_storage(force=True)
        resp = requests.put(f"{STORAGE_URL}/objects/{path}", headers={"X-Storage-Key": key, "Content-Type": content_type}, data=data, timeout=120)
    resp.raise_for_status()
    return resp.json()

def get_object(path):
    key = init_storage()
    resp = requests.get(f"{STORAGE_URL}/objects/{path}", headers={"X-Storage-Key": key}, timeout=60)
    if resp.status_code == 404:
        key = init_storage(force=True)
        resp = requests.get(f"{STORAGE_URL}/objects/{path}", headers={"X-Storage-Key": key}, timeout=60)
    resp.raise_for_status()
    return resp.content, resp.headers.get("Content-Type", "application/octet-stream")

# ---------------------- Auth helpers ---------------------------------------
def hash_pw(p): return bcrypt.hashpw(p.encode(), bcrypt.gensalt()).decode()
def verify_pw(p, h):
    try: return bcrypt.checkpw(p.encode(), h.encode())
    except Exception: return False

def create_token(user):
    payload = {"sub": user["id"], "email": user["email"], "role": user["role"],
               "exp": now() + timedelta(minutes=ACCESS_TTL_MIN), "type": "access"}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

async def get_current_user(request: Request):
    token = None
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "): token = auth[7:]
    if not token: token = request.cookies.get("access_token")
    if not token: raise HTTPException(401, "Not authenticated")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Session expired")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid token")
    user = await db.users.find_one({"id": payload["sub"]}, {"_id": 0, "password_hash": 0})
    if not user: raise HTTPException(401, "User not found")
    return user

def require_owner(user=Depends(get_current_user)):
    if user["role"] != "owner":
        raise HTTPException(403, "Owner access required")
    return user

# ---------------------- Email ----------------------------------------------
_SHORTENERS = ("bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "goo.gl", "rebrand.ly")
_CRED_ASK = ("reply with your password", "reply with the code", "send your password", "cvv",
             "send us your password", "enter your password below", "confirm your card number",
             "your full card number", "seed phrase", "recovery phrase", "verify your card",
             "social security number", "confirm your bank details")
_HOSTISH = re.compile(r"\b(?:https?://)?((?:[a-z0-9-]+\.)+[a-z]{2,})", re.I)

def _host_ok(host):
    if not host or "xn--" in host: return False
    try:
        ipaddress.ip_address(host); return False
    except ValueError: pass
    return not any(host == s or host.endswith("." + s) for s in _SHORTENERS)

def _same_site(shown, real):
    return shown == real or real.endswith("." + shown) or shown.endswith("." + real)

class _EmailScan(HTMLParser):
    def __init__(self):
        super().__init__(); self.tags, self.urls, self.anchors = set(), [], []
        self._href, self._text = None, []
    def handle_starttag(self, tag, attrs):
        self.tags.add(tag.lower())
        self.urls += [v for k, v in attrs if k.lower() in ("href", "src") and v]
        if tag.lower() == "a":
            self._href = dict((k.lower(), v) for k, v in attrs).get("href"); self._text = []
    def handle_data(self, data):
        if self._href is not None: self._text.append(data)
    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            self.anchors.append((self._href, "".join(self._text))); self._href, self._text = None, []

def _assert_safe_email(subject, html):
    scan = _EmailScan(); scan.feed(html)
    if scan.tags & {"form", "input", "textarea", "select"}:
        raise ValueError("No forms in email (G2)")
    body = f"{subject}\n{html}".lower()
    for p in _CRED_ASK:
        if p in body: raise ValueError(f"Credential ask: {p!r}")
    for url in scan.urls:
        low = url.strip().lower()
        if low.startswith(("mailto:", "tel:", "cid:", "#")): continue
        if not low.startswith("https://"): raise ValueError(f"Non-https link: {url!r}")
        host = urlparse(low).hostname or ""
        if not _host_ok(host) or urlparse(low).username is not None:
            raise ValueError(f"Bad URL: {url!r}")
    for href, text in scan.anchors:
        real = urlparse(href.strip().lower()).hostname or ""
        if not real: continue
        for m in _HOSTISH.finditer(text):
            if not _same_site(m.group(1).lower(), real):
                raise ValueError(f"Anchor mismatch {m.group(1)!r} != {real!r}")

async def send_email(*, to, subject, html):
    if not EMAIL_KEY:
        logger.warning("Email key missing, skipping send"); return None
    _assert_safe_email(subject, html)
    payload = {"to": [to], "subject": subject, "html": html, "from_name": EMAIL_FROM_NAME}
    if EMAIL_REPLY_TO: payload["contact_email"] = EMAIL_REPLY_TO
    try:
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post(f"{EMAIL_BASE_URL}/api/v1/email/send",
                             headers={"X-Email-Key": EMAIL_KEY}, json=payload)
        r.raise_for_status()
        return r.json().get("id")
    except Exception as e:
        logger.error(f"Email failed: {e}")
        return None

def email_wrap(inner):
    return (f'<table role="presentation" width="100%" style="background:#FBF3E2;padding:24px 0">'
            f'<tr><td align="center"><table role="presentation" width="560" style="background:#fff;'
            f'border-radius:16px;overflow:hidden;font-family:Arial,sans-serif">'
            f'<tr><td style="background:#0A1F44;padding:20px 28px"><span style="color:#F4B73F;'
            f'font-size:20px;font-weight:bold">The Kalyan Chronicles</span>'
            f'<span style="color:#FBF3E2;font-size:12px"> &nbsp;Inspire &amp; Inform</span></td></tr>'
            f'<tr><td style="padding:28px">{inner}</td></tr>'
            f'<tr><td style="padding:18px 28px;background:#F6EEDC;font-size:12px;color:#718096">'
            f'Sent by The Kalyan Chronicles. We never ask for your password by email.</td></tr>'
            f'</table></td></tr></table>')

# ---------------------- YouTube -------------------------------------------
YT_RE = re.compile(r'(?:youtube\.com/(?:watch\?v=|shorts/|embed/)|youtu\.be/)([A-Za-z0-9_-]{11})')
def extract_video_id(url):
    if not url: return None
    m = YT_RE.search(url)
    if m: return m.group(1)
    m2 = re.search(r'[?&]v=([A-Za-z0-9_-]{11})', url)
    return m2.group(1) if m2 else None

def yt_thumb(vid): return f"https://img.youtube.com/vi/{vid}/hqdefault.jpg" if vid else None

def slugify(s):
    s = re.sub(r'[^\w\s-]', '', (s or '').lower()).strip()
    return re.sub(r'[-\s]+', '-', s)[:60] or new_id()[:8]

# ---------------------- Models --------------------------------------------
class LoginIn(BaseModel):
    email: EmailStr
    password: str

class GuestIn(BaseModel):
    name: str
    designation: str = ""
    topic: str = ""
    photo_url: str = ""
    youtube_url: str = ""
    title_en: str = ""
    title_te: str = ""
    synopsis_en: str = ""
    synopsis_te: str = ""
    bio: str = ""
    episode_date: str = ""
    tags: List[str] = []
    featured: bool = False
    pinned: bool = False
    status: str = "draft"
    te_reviewed: bool = False

class TranslateIn(BaseModel):
    title_en: str = ""
    synopsis_en: str = ""

class ApplicationIn(BaseModel):
    name: str
    email: EmailStr
    phone: str = ""
    city: str = ""
    profession: str = ""
    organisation: str = ""
    expertise: str = ""
    bio: str = ""
    topics: str = ""
    links: str = ""
    consent: bool = False
    honeypot: str = ""

class NewsletterIn(BaseModel):
    email: EmailStr
    name: str = ""
    language: str = "both"
    consent: bool = False
    honeypot: str = ""

class AdInquiryIn(BaseModel):
    company: str
    contact_name: str
    email: EmailStr
    phone: str = ""
    budget: str = ""
    ad_type: str = ""
    message: str = ""
    honeypot: str = ""

class AdIn(BaseModel):
    advertiser: str
    image_url: str = ""
    headline: str = ""
    destination_url: str = ""
    slots: List[str] = []
    start_date: str = ""
    end_date: str = ""
    status: str = "active"
    priority: int = 1
    language: str = "all"
    embed_code: str = ""
    embed_enabled: bool = False

class EventIn(BaseModel):
    type: str
    video_id: Optional[str] = None
    meta: Optional[dict] = None

# ---------------------- Public: settings -----------------------------------
DEFAULT_SETTINGS = {
    "site_name": "The Kalyan Chronicles",
    "tagline_en": "Inspire & Inform",
    "tagline_te": "ప్రేరణ & సమాచారం",
    "about_en": "The Kalyan Chronicles, hosted by Kalyan K Bharath, brings you meaningful Telugu-first conversations with inspiring guests from diverse fields. Drawing on his previous experience as a Radio Presenter and Podcast Host at Spice FM in the UK, Kalyan continues to share stories, ideas, and insights through his ongoing YouTube podcast series.",
    "about_te": "ది కల్యాణ్ క్రానికల్స్, కళ్యాణ్ కే భరత్ హోస్ట్ చేస్తున్న ఈ కార్యక్రమం, విభిన్న రంగాలకు చెందిన స్ఫూర్తిదాయక అతిథులతో అర్థవంతమైన తెలుగు-మొదటి సంభాషణలను మీకు అందిస్తుంది. యూకేలోని స్పైస్ ఎఫ్ఎమ్‌లో రేడియో ప్రెజెంటర్ మరియు పాడ్‌కాస్ట్ హోస్ట్‌గా తన గత అనుభవాన్ని ఆధారంగా చేసుకుని, కళ్యాణ్ తన కొనసాగుతున్న యూట్యూబ్ పాడ్‌కాస్ట్ సిరీస్ ద్వారా కథలు, ఆలోచనలు మరియు అంతర్దృష్టులను పంచుకుంటూనే ఉన్నారు.",
    "mission_en": "Real Conversations. Real People. Real Impact.",
    "mission_te": "నిజమైన సంభాషణలు. నిజమైన వ్యక్తులు. నిజమైన ప్రభావం.",
    "values_en": ["Telugu-first conversations", "Inspiring guests and real stories", "Insights that inform and empower"],
    "values_te": ["తెలుగు-మొదటి సంభాషణలు", "స్ఫూర్తిదాయక అతిథులు మరియు నిజమైన కథలు", "సమాచారం ఇచ్చి సాధికారత కల్పించే అంతర్దృష్టులు"],
    "site_images": {},
    "youtube_channel_url": "https://www.youtube.com/@TheKalyanChronicles",
    "host_name_en": "Meet Kalyan K Bharath",
    "host_name_te": "కళ్యాణ్ కే భరత్‌ను కలవండి",
    "host_bio_en": "Kalyan K Bharath is an entrepreneur, business systems professional, and podcast host with a passion for people, ideas, and meaningful conversations. He holds an MSc in Computer Science from Teesside University in the United Kingdom, bringing an academic and professional perspective to his work.\n\nHis previous experience as a Radio Presenter and Podcast Host at Spice FM in the UK helped shape his approach to interviewing, communication, and storytelling.\n\nThrough The Kalyan Chronicles, Kalyan continues to connect with inspiring guests, explore diverse perspectives, and share meaningful stories through an ongoing Telugu-first YouTube podcast.",
    "host_bio_te": "కళ్యాణ్ కే భరత్ ఒక వ్యవస్థాపకుడు, బిజినెస్ సిస్టమ్స్ నిపుణుడు మరియు పాడ్‌కాస్ట్ హోస్ట్ — వ్యక్తులు, ఆలోచనలు మరియు అర్థవంతమైన సంభాషణల పట్ల ఆయనకు ప్రత్యేక అభిరుచి ఉంది. ఆయన యునైటెడ్ కింగ్‌డమ్‌లోని టీస్‌సైడ్ యూనివర్శిటీ నుండి కంప్యూటర్ సైన్స్‌లో ఎమ్మెస్సీ పూర్తి చేసారు, ఇది ఆయన పనికి విద్యాపరమైన మరియు వృత్తిపరమైన దృక్కోణాన్ని జోడిస్తుంది.\n\nయూకేలోని స్పైస్ ఎఫ్ఎమ్‌లో రేడియో ప్రెజెంటర్ మరియు పాడ్‌కాస్ట్ హోస్ట్‌గా ఆయన గత అనుభవం, ఇంటర్వ్యూ, కమ్యూనికేషన్ మరియు కథనం పట్ల ఆయన దృక్పథాన్ని రూపొందించడంలో సహాయపడింది.\n\nది కల్యాణ్ క్రానికల్స్ ద్వారా, కళ్యాణ్ స్ఫూర్తిదాయక అతిథులతో కనెక్ట్ అవుతూ, విభిన్న దృక్కోణాలను అన్వేషిస్తూ, కొనసాగుతున్న తెలుగు-మొదటి యూట్యూబ్ పాడ్‌కాస్ట్ ద్వారా అర్థవంతమైన కథలను పంచుకుంటూనే ఉన్నారు.",
    "epaper_url": "",
    "instagram_url": "https://instagram.com/thekalyanchronicles",
    "social_links": [
        {"label": "YouTube", "url": "https://www.youtube.com/@TheKalyanChronicles"},
        {"label": "Instagram", "url": "https://instagram.com/thekalyanchronicles"}
    ],
    "contact_email": "shashikirancb@gmail.com",
    "hero_stats": [
        {"label_en": "Subscribers", "label_te": "చందాదారులు", "value": "100K+"},
        {"label_en": "Episodes", "label_te": "ఎపిసోడ్లు", "value": "50+"},
        {"label_en": "Guests", "label_te": "అతిథులు", "value": "48"}
    ],
    "advertise_audience_en": "Our audience is young, curious, and Telugu-speaking — students, professionals, entrepreneurs, and families across Telangana, Andhra Pradesh, and the global Telugu diaspora.",
    "advertise_audience_te": "మా ప్రేక్షకులు యువత, ఆసక్తిగలవారు మరియు తెలుగు మాట్లాడేవారు — విద్యార్థులు, నిపుణులు, వ్యవస్థాపకులు మరియు కుటుంబాలు.",
    "advertise_reach": [
        {"label_en": "Monthly Views", "label_te": "నెలవారీ వీక్షణలు", "value": "5M+"},
        {"label_en": "Watch Time", "label_te": "వీక్షణ సమయం", "value": "320K hrs"},
        {"label_en": "Avg. Age", "label_te": "సగటు వయస్సు", "value": "22-40"}
    ],
    "rate_card": [
        {"format": "Header Banner", "price": "Starting from ₹15,000/mo"},
        {"format": "In-feed Card", "price": "Starting from ₹10,000/mo"},
        {"format": "Sidebar", "price": "Starting from ₹8,000/mo"},
        {"format": "Newsletter Sponsorship", "price": "Starting from ₹12,000"},
        {"format": "Sponsored Episode Shout-out", "price": "Contact us"},
        {"format": "E-Paper Placement", "price": "Contact us"}
    ],
    "media_kit_url": "",
    "topics": ["Science", "Health", "Money", "Parenting", "Spirituality", "Society", "Business", "Technology", "Cinema", "Politics", "Coaching", "Entrepreneurship", "Other"],
    "seo_title": "The Kalyan Chronicles — Telugu Podcast & Interviews",
    "seo_description": "Telugu-first interviews that Inspire & Inform. Watch on YouTube.",
}

async def get_settings_doc():
    doc = await db.settings.find_one({"id": "site"}, {"_id": 0})
    if not doc:
        doc = {"id": "site", **DEFAULT_SETTINGS}
        await db.settings.insert_one(dict(doc))
    merged = {**DEFAULT_SETTINGS, **doc}
    return merged

@api.get("/settings")
async def public_settings():
    s = await get_settings_doc()
    return s

# ---------------------- Public: guests -------------------------------------
def clean_guest(g, public=True):
    g.pop("_id", None)
    vid = extract_video_id(g.get("youtube_url", ""))
    g["video_id"] = vid
    g["thumbnail"] = g.get("photo_url") or yt_thumb(vid) or ""
    g["yt_thumbnail"] = yt_thumb(vid) or ""
    return g

@api.get("/guests")
async def list_guests(q: str = "", topic: str = "", sort: str = "newest",
                      page: int = 1, limit: int = 9):
    query = {"status": "published"}
    if topic and topic != "all": query["topic"] = topic
    if q:
        rx = {"$regex": re.escape(q), "$options": "i"}
        query["$or"] = [{"name": rx}, {"topic": rx}, {"title_en": rx}, {"title_te": rx},
                        {"synopsis_en": rx}, {"synopsis_te": rx}]
    sort_spec = [("name", 1)] if sort == "az" else [("episode_date", -1), ("created_at", -1)]
    total = await db.guests.count_documents(query)
    cursor = db.guests.find(query).sort(sort_spec).skip((page-1)*limit).limit(limit)
    items = [clean_guest(g) async for g in cursor]
    return {"items": items, "total": total, "page": page, "limit": limit,
            "pages": (total + limit - 1)//limit}

@api.get("/guests/featured")
async def featured_guests():
    cursor = db.guests.find({"status": "published", "featured": True}).sort(
        [("order", 1), ("episode_date", -1)]).limit(8)
    return [clean_guest(g) async for g in cursor]

@api.get("/guests/latest")
async def latest_guest():
    g = await db.guests.find_one({"status": "published", "pinned": True})
    if not g:
        g = await db.guests.find_one({"status": "published"},
                                     sort=[("episode_date", -1), ("created_at", -1)])
    return clean_guest(g) if g else None

@api.get("/guests/{slug}")
async def guest_detail(slug: str):
    g = await db.guests.find_one({"slug": slug, "status": "published"})
    if not g: raise HTTPException(404, "Guest not found")
    g = clean_guest(g)
    related = db.guests.find({"status": "published", "topic": g.get("topic"),
                              "slug": {"$ne": slug}}).limit(3)
    g["related"] = [clean_guest(r) async for r in related]
    return g

# ---------------------- Public: ads ----------------------------------------
def ad_active(ad):
    if ad.get("status") != "active": return False
    today = now().date().isoformat()
    if ad.get("start_date") and ad["start_date"] > today: return False
    if ad.get("end_date") and ad["end_date"] < today: return False
    return True

@api.get("/ads/{slot}")
async def get_ad(slot: str, lang: str = "en"):
    cursor = db.ads.find({"slots": slot})
    ads = [a async for a in cursor]
    ads = [a for a in ads if ad_active(a) and (a.get("language", "all") in ("all", lang))]
    if not ads: return None
    ads.sort(key=lambda a: a.get("priority", 1), reverse=True)
    ad = ads[0]
    ad.pop("_id", None)
    return ad

@api.post("/ads/{ad_id}/impression")
async def ad_impression(ad_id: str):
    await db.ads.update_one({"id": ad_id}, {"$inc": {"impressions": 1}})
    await db.ad_stats.insert_one({"ad_id": ad_id, "type": "impression", "date": now().date().isoformat(), "ts": iso()})
    return {"ok": True}

@api.post("/ads/{ad_id}/click")
async def ad_click(ad_id: str):
    await db.ads.update_one({"id": ad_id}, {"$inc": {"clicks": 1}})
    await db.ad_stats.insert_one({"ad_id": ad_id, "type": "click", "date": now().date().isoformat(), "ts": iso()})
    return {"ok": True}

# ---------------------- Public: analytics events ---------------------------
@api.post("/events")
async def track_event(e: EventIn):
    await db.events.insert_one({"id": new_id(), "type": e.type, "video_id": e.video_id,
                                "meta": e.meta or {}, "date": now().date().isoformat(), "ts": iso()})
    return {"ok": True}

# ---------------------- Public: applications -------------------------------
@api.post("/applications")
async def create_application(a: ApplicationIn):
    if a.honeypot: return {"ok": True}  # silently drop bots
    if not a.consent: raise HTTPException(400, "Consent is required")
    if len(a.bio) > 500: raise HTTPException(400, "Bio too long")
    doc = {"id": new_id(), **a.model_dump(), "status": "new", "notes": "", "created_at": iso()}
    doc.pop("honeypot", None)
    await db.applications.insert_one(dict(doc))
    await db.events.insert_one({"id": new_id(), "type": "guest_application", "date": now().date().isoformat(), "ts": iso()})
    inner = (f'<h2 style="color:#0A1F44;margin:0 0 12px">Thanks, {escape(a.name)}! 🎙️</h2>'
             f'<p style="color:#333;line-height:1.6">We received your request to be a guest on '
             f'<strong>The Kalyan Chronicles</strong>. Our team will review your profile and reach out '
             f'if it is a good fit.</p>'
             f'<p style="color:#333;line-height:1.6">Topic interest: {escape(a.expertise or "—")}</p>')
    await send_email(to=a.email, subject="We received your guest application — The Kalyan Chronicles",
                     html=email_wrap(inner))
    admin_email = (await get_settings_doc()).get("contact_email")
    if admin_email:
        ai = (f'<h3 style="color:#0A1F44">New guest application</h3>'
              f'<p><strong>{escape(a.name)}</strong> — {escape(a.profession)} @ {escape(a.organisation)}</p>'
              f'<p>Email: {escape(a.email)}<br>Phone: {escape(a.phone)}<br>City: {escape(a.city)}</p>'
              f'<p>Expertise: {escape(a.expertise)}<br>Topics: {escape(a.topics)}</p>'
              f'<p>{escape(a.bio)}</p>')
        await send_email(to=admin_email, subject="New guest application received", html=email_wrap(ai))
    return {"ok": True, "message": "Application submitted"}

# ---------------------- Public: newsletter ---------------------------------
@api.post("/newsletter/subscribe")
async def newsletter_subscribe(n: NewsletterIn):
    if n.honeypot: return {"ok": True}
    if not n.consent: raise HTTPException(400, "Consent is required")
    email = n.email.lower()
    existing = await db.subscribers.find_one({"email": email})
    token = secrets.token_urlsafe(24)
    if existing and existing.get("status") == "confirmed":
        return {"ok": True, "message": "Already subscribed"}
    doc = {"id": existing["id"] if existing else new_id(), "email": email, "name": n.name,
           "language": n.language, "status": "pending", "confirm_token": token,
           "unsub_token": existing.get("unsub_token") if existing else secrets.token_urlsafe(24),
           "created_at": iso()}
    await db.subscribers.update_one({"email": email}, {"$set": doc}, upsert=True)
    link = f"{PUBLIC_URL}/api/newsletter/confirm?token={token}"
    inner = (f'<h2 style="color:#0A1F44;margin:0 0 12px">Confirm your subscription</h2>'
             f'<p style="color:#333;line-height:1.6">Thanks for subscribing to The Kalyan Chronicles newsletter. '
             f'Please confirm your email to start receiving our latest episodes.</p>'
             f'<p style="margin:24px 0"><a href="{link}" style="background:#F4B73F;color:#0A1F44;'
             f'text-decoration:none;font-weight:bold;padding:12px 24px;border-radius:14px;display:inline-block">'
             f'Confirm subscription</a></p>')
    await send_email(to=email, subject="Confirm your subscription — The Kalyan Chronicles",
                     html=email_wrap(inner))
    return {"ok": True, "message": "Check your email to confirm"}

@api.get("/newsletter/confirm", response_class=HTMLResponse)
async def newsletter_confirm(token: str):
    sub = await db.subscribers.find_one({"confirm_token": token})
    if sub:
        await db.subscribers.update_one({"id": sub["id"]},
            {"$set": {"status": "confirmed", "confirmed_at": iso()}, "$unset": {"confirm_token": ""}})
        await db.events.insert_one({"id": new_id(), "type": "newsletter_signup", "date": now().date().isoformat(), "ts": iso()})
        msg = "You're confirmed! 🎉 Thanks for subscribing."
    else:
        msg = "This confirmation link is invalid or already used."
    return HTMLResponse(f'<html><body style="font-family:Arial;background:#FBF3E2;text-align:center;padding:60px">'
                        f'<h1 style="color:#0A1F44">The Kalyan Chronicles</h1><p style="font-size:18px;color:#333">{msg}</p>'
                        f'<a href="{PUBLIC_URL}" style="color:#0F2F63">Back to site</a></body></html>')

@api.get("/newsletter/unsubscribe", response_class=HTMLResponse)
async def newsletter_unsubscribe(token: str):
    sub = await db.subscribers.find_one({"unsub_token": token})
    if sub:
        await db.subscribers.update_one({"id": sub["id"]}, {"$set": {"status": "unsubscribed"}})
        msg = "You have been unsubscribed."
    else:
        msg = "Invalid link."
    return HTMLResponse(f'<html><body style="font-family:Arial;background:#FBF3E2;text-align:center;padding:60px">'
                        f'<h1 style="color:#0A1F44">The Kalyan Chronicles</h1><p>{msg}</p></body></html>')

# ---------------------- Public: ad inquiries -------------------------------
@api.post("/ad-inquiries")
async def create_ad_inquiry(a: AdInquiryIn):
    if a.honeypot: return {"ok": True}
    doc = {"id": new_id(), **a.model_dump(), "status": "new", "notes": "", "created_at": iso()}
    doc.pop("honeypot", None)
    await db.ad_inquiries.insert_one(dict(doc))
    await db.events.insert_one({"id": new_id(), "type": "click_advertise", "date": now().date().isoformat(), "ts": iso()})
    admin_email = (await get_settings_doc()).get("contact_email")
    if admin_email:
        inner = (f'<h3 style="color:#0A1F44">New advertiser inquiry</h3>'
                 f'<p><strong>{escape(a.company)}</strong> — {escape(a.contact_name)}</p>'
                 f'<p>Email: {escape(a.email)}<br>Phone: {escape(a.phone)}<br>Budget: {escape(a.budget)}<br>'
                 f'Ad type: {escape(a.ad_type)}</p><p>{escape(a.message)}</p>')
        await send_email(to=admin_email, subject="New advertiser inquiry", html=email_wrap(inner))
    return {"ok": True, "message": "Inquiry submitted"}

@api.post("/admin/upload-image")
async def upload_image(file: UploadFile = File(...), user=Depends(get_current_user)):
    ext = (file.filename.rsplit(".", 1)[-1] if "." in (file.filename or "") else "png").lower()
    if ext not in MIME:
        raise HTTPException(400, "Only JPG, PNG, WEBP or GIF images are allowed")
    data = await file.read()
    if len(data) > 5 * 1024 * 1024:
        raise HTTPException(400, "Image must be under 5MB")
    path = f"{APP_NAME}/guests/{new_id()}.{ext}"
    content_type = MIME[ext]
    try:
        result = put_object(path, data, content_type)
    except Exception as e:
        logger.error(f"Upload failed: {e}")
        raise HTTPException(502, "Upload failed")
    await db.files.insert_one({"id": new_id(), "storage_path": result["path"],
                               "content_type": content_type, "size": result.get("size", len(data)),
                               "is_deleted": False, "created_at": iso()})
    return {"url": f"{PUBLIC_URL}/api/files/{result['path']}"}

@api.get("/files/{path:path}")
async def serve_file(path: str):
    record = await db.files.find_one({"storage_path": path, "is_deleted": False})
    try:
        data, content_type = get_object(path)
    except Exception:
        raise HTTPException(404, "File not found")
    ct = record.get("content_type") if record else content_type
    return Response(content=data, media_type=ct, headers={"Cache-Control": "public, max-age=86400"})

# ---------------------- Auth endpoints -------------------------------------
@api.post("/auth/login")
async def login(data: LoginIn):
    user = await db.users.find_one({"email": data.email.lower()})
    if not user or not verify_pw(data.password, user["password_hash"]):
        raise HTTPException(401, "Invalid email or password")
    u = {"id": user["id"], "email": user["email"], "role": user["role"], "name": user.get("name", "")}
    return {"access_token": create_token(u), "user": u}

@api.get("/auth/me")
async def me(user=Depends(get_current_user)):
    return user

@api.post("/auth/logout")
async def logout():
    return {"ok": True}

# ---------------------- Admin: dashboard -----------------------------------
@api.get("/admin/dashboard")
async def dashboard(user=Depends(get_current_user)):
    week_ago = (now() - timedelta(days=7)).date().isoformat()
    async def count_event(t):
        return await db.events.count_documents({"type": t, "date": {"$gte": week_ago}})
    guests_total = await db.guests.count_documents({})
    published = await db.guests.count_documents({"status": "published"})
    subs = await db.subscribers.count_documents({"status": "confirmed"})
    apps = await db.applications.count_documents({})
    inquiries = await db.ad_inquiries.count_documents({})
    top_pipeline = [{"$match": {"type": "click_youtube", "video_id": {"$ne": None},
                                "date": {"$gte": week_ago}}},
                    {"$group": {"_id": "$video_id", "clicks": {"$sum": 1}}},
                    {"$sort": {"clicks": -1}}, {"$limit": 5}]
    top = await db.events.aggregate(top_pipeline).to_list(5)
    top_guests = []
    for t in top:
        g = await db.guests.find_one({"youtube_url": {"$regex": t["_id"]}}, {"_id": 0, "name": 1, "slug": 1})
        if g: top_guests.append({"name": g["name"], "slug": g.get("slug"), "clicks": t["clicks"]})
    latest_apps = [a async for a in db.applications.find({}, {"_id": 0}).sort("created_at", -1).limit(5)]
    return {
        "totals": {"guests": guests_total, "published": published, "subscribers": subs,
                   "applications": apps, "inquiries": inquiries},
        "clicks_week": {"youtube": await count_event("click_youtube"),
                        "epaper": await count_event("click_epaper"),
                        "advertise": await count_event("click_advertise"),
                        "newsletter": await count_event("newsletter_signup")},
        "top_guests": top_guests,
        "latest_applications": latest_apps,
    }

# ---------------------- Admin: guests CRUD ---------------------------------
@api.get("/admin/guests")
async def admin_list_guests(user=Depends(get_current_user), q: str = "", status: str = "", topic: str = ""):
    query = {}
    if status and status != "all": query["status"] = status
    if topic and topic != "all": query["topic"] = topic
    if q:
        rx = {"$regex": re.escape(q), "$options": "i"}
        query["$or"] = [{"name": rx}, {"title_en": rx}, {"topic": rx}]
    cursor = db.guests.find(query).sort([("order", 1), ("created_at", -1)])
    return [clean_guest(g) async for g in cursor]

@api.post("/admin/guests")
async def admin_create_guest(g: GuestIn, user=Depends(get_current_user)):
    vid = extract_video_id(g.youtube_url)
    if g.youtube_url and not vid:
        raise HTTPException(400, "Invalid YouTube URL")
    doc = g.model_dump()
    doc["id"] = new_id()
    doc["slug"] = f"{slugify(g.name)}-{doc['id'][:6]}"
    doc["impressions"] = 0
    doc["order"] = await db.guests.count_documents({})
    doc["created_at"] = iso()
    if g.pinned:
        await db.guests.update_many({}, {"$set": {"pinned": False}})
    await db.guests.insert_one(dict(doc))
    return clean_guest(doc)

@api.put("/admin/guests/{gid}")
async def admin_update_guest(gid: str, g: GuestIn, user=Depends(get_current_user)):
    vid = extract_video_id(g.youtube_url)
    if g.youtube_url and not vid:
        raise HTTPException(400, "Invalid YouTube URL")
    existing = await db.guests.find_one({"id": gid})
    if not existing: raise HTTPException(404, "Not found")
    if g.pinned and not existing.get("pinned"):
        await db.guests.update_many({}, {"$set": {"pinned": False}})
    doc = g.model_dump()
    doc["updated_at"] = iso()
    await db.guests.update_one({"id": gid}, {"$set": doc})
    return clean_guest(await db.guests.find_one({"id": gid}))

@api.post("/admin/guests/{gid}/duplicate")
async def admin_duplicate_guest(gid: str, user=Depends(get_current_user)):
    g = await db.guests.find_one({"id": gid}, {"_id": 0})
    if not g: raise HTTPException(404, "Not found")
    g["id"] = new_id()
    g["name"] = g["name"] + " (Copy)"
    g["slug"] = f"{slugify(g['name'])}-{g['id'][:6]}"
    g["status"] = "draft"
    g["pinned"] = False
    g["created_at"] = iso()
    await db.guests.insert_one(dict(g))
    return clean_guest(g)

@api.delete("/admin/guests/{gid}")
async def admin_delete_guest(gid: str, user=Depends(get_current_user)):
    await db.guests.delete_one({"id": gid})
    return {"ok": True}

@api.post("/admin/guests/reorder")
async def admin_reorder(payload: dict, user=Depends(get_current_user)):
    for i, gid in enumerate(payload.get("ids", [])):
        await db.guests.update_one({"id": gid}, {"$set": {"order": i}})
    return {"ok": True}

@api.post("/admin/guests/bulk")
async def admin_bulk(payload: dict, user=Depends(get_current_user)):
    ids = payload.get("ids", []); action = payload.get("action")
    if action == "publish": await db.guests.update_many({"id": {"$in": ids}}, {"$set": {"status": "published"}})
    elif action == "unpublish": await db.guests.update_many({"id": {"$in": ids}}, {"$set": {"status": "draft"}})
    elif action == "delete": await db.guests.delete_many({"id": {"$in": ids}})
    return {"ok": True}

@api.post("/admin/translate")
async def admin_translate(data: TranslateIn, user=Depends(get_current_user)):
    try:
        from emergentintegrations.llm.chat import LlmChat, UserMessage
        chat = LlmChat(api_key=EMERGENT_LLM_KEY, session_id=f"translate-{new_id()}",
                       system_message=("You are a professional English to Telugu translator for a podcast. "
                                       "Translate naturally and conversationally. Return ONLY valid JSON with keys "
                                       "'title_te' and 'synopsis_te'. No markdown, no explanation.")).with_model("openai", "gpt-5.4")
        prompt = f"Translate to Telugu.\nTitle: {data.title_en}\nSynopsis: {data.synopsis_en}"
        resp = await chat.send_message(UserMessage(text=prompt))
        text = resp if isinstance(resp, str) else str(resp)
        import json
        m = re.search(r'\{.*\}', text, re.DOTALL)
        if m:
            parsed = json.loads(m.group(0))
            return {"title_te": parsed.get("title_te", ""), "synopsis_te": parsed.get("synopsis_te", "")}
        return {"title_te": "", "synopsis_te": text}
    except Exception as e:
        logger.error(f"Translate failed: {e}")
        raise HTTPException(500, "Translation failed")

# ---------------------- Admin: applications --------------------------------
@api.get("/admin/applications")
async def admin_applications(user=Depends(get_current_user), status: str = "", q: str = ""):
    query = {}
    if status and status != "all": query["status"] = status
    if q:
        rx = {"$regex": re.escape(q), "$options": "i"}
        query["$or"] = [{"name": rx}, {"email": rx}, {"expertise": rx}]
    return [a async for a in db.applications.find(query, {"_id": 0}).sort("created_at", -1)]

@api.put("/admin/applications/{aid}")
async def admin_update_application(aid: str, payload: dict, user=Depends(get_current_user)):
    upd = {}
    if "status" in payload: upd["status"] = payload["status"]
    if "notes" in payload: upd["notes"] = payload["notes"]
    await db.applications.update_one({"id": aid}, {"$set": upd})
    return {"ok": True}

# ---------------------- Admin: subscribers ---------------------------------
@api.get("/admin/subscribers")
async def admin_subscribers(user=Depends(get_current_user), status: str = ""):
    query = {}
    if status and status != "all": query["status"] = status
    return [s async for s in db.subscribers.find(query, {"_id": 0, "confirm_token": 0}).sort("created_at", -1)]

@api.post("/admin/subscribers")
async def admin_add_subscriber(payload: dict, user=Depends(get_current_user)):
    email = payload["email"].lower()
    doc = {"id": new_id(), "email": email, "name": payload.get("name", ""),
           "language": payload.get("language", "both"), "status": "confirmed",
           "unsub_token": secrets.token_urlsafe(24), "created_at": iso(), "confirmed_at": iso()}
    await db.subscribers.update_one({"email": email}, {"$set": doc}, upsert=True)
    return {"ok": True}

# ---------------------- Admin: ads -----------------------------------------
@api.get("/admin/ads")
async def admin_ads(user=Depends(get_current_user)):
    out = []
    async for a in db.ads.find({}, {"_id": 0}).sort("created_at", -1):
        imp = a.get("impressions", 0); clk = a.get("clicks", 0)
        a["ctr"] = round((clk/imp*100), 2) if imp else 0
        out.append(a)
    return out

@api.post("/admin/ads")
async def admin_create_ad(ad: AdIn, user=Depends(get_current_user)):
    doc = ad.model_dump()
    doc.update({"id": new_id(), "impressions": 0, "clicks": 0, "created_at": iso()})
    await db.ads.insert_one(dict(doc))
    doc.pop("_id", None)
    return doc

@api.put("/admin/ads/{aid}")
async def admin_update_ad(aid: str, ad: AdIn, user=Depends(get_current_user)):
    await db.ads.update_one({"id": aid}, {"$set": ad.model_dump()})
    return {"ok": True}

@api.delete("/admin/ads/{aid}")
async def admin_delete_ad(aid: str, user=Depends(get_current_user)):
    await db.ads.delete_one({"id": aid})
    return {"ok": True}

@api.get("/admin/ads/{aid}/report")
async def admin_ad_report(aid: str, user=Depends(get_current_user)):
    ad = await db.ads.find_one({"id": aid}, {"_id": 0})
    if not ad: raise HTTPException(404, "Not found")
    pipeline = [{"$match": {"ad_id": aid}},
                {"$group": {"_id": {"date": "$date", "type": "$type"}, "n": {"$sum": 1}}}]
    rows = await db.ad_stats.aggregate(pipeline).to_list(1000)
    daily = {}
    for r in rows:
        d = r["_id"]["date"]; daily.setdefault(d, {"date": d, "impressions": 0, "clicks": 0})
        daily[d][r["_id"]["type"] + "s"] = r["n"]
    series = sorted(daily.values(), key=lambda x: x["date"])
    return {"ad": ad, "daily": series}

# ---------------------- Admin: ad inquiries --------------------------------
@api.get("/admin/ad-inquiries")
async def admin_ad_inquiries(user=Depends(get_current_user), status: str = ""):
    query = {}
    if status and status != "all": query["status"] = status
    return [a async for a in db.ad_inquiries.find(query, {"_id": 0}).sort("created_at", -1)]

@api.put("/admin/ad-inquiries/{aid}")
async def admin_update_inquiry(aid: str, payload: dict, user=Depends(get_current_user)):
    upd = {k: payload[k] for k in ("status", "notes") if k in payload}
    await db.ad_inquiries.update_one({"id": aid}, {"$set": upd})
    return {"ok": True}

# ---------------------- Admin: settings ------------------------------------
@api.put("/admin/settings")
async def admin_update_settings(payload: dict, user=Depends(get_current_user)):
    payload.pop("id", None); payload.pop("_id", None)
    await db.settings.update_one({"id": "site"}, {"$set": payload}, upsert=True)
    return await get_settings_doc()

# ---------------------- Admin: users (owner) -------------------------------
@api.get("/admin/users")
async def admin_users(user=Depends(require_owner)):
    return [u async for u in db.users.find({}, {"_id": 0, "password_hash": 0})]

@api.post("/admin/users")
async def admin_create_user(payload: dict, user=Depends(require_owner)):
    email = payload["email"].lower()
    if await db.users.find_one({"email": email}): raise HTTPException(400, "Email exists")
    doc = {"id": new_id(), "email": email, "name": payload.get("name", ""),
           "role": payload.get("role", "editor"), "password_hash": hash_pw(payload["password"]),
           "created_at": iso()}
    await db.users.insert_one(doc)
    return {"ok": True}

@api.delete("/admin/users/{uid}")
async def admin_delete_user(uid: str, user=Depends(require_owner)):
    await db.users.delete_one({"id": uid, "role": {"$ne": "owner"}})
    return {"ok": True}

# ---------------------- Seed & startup -------------------------------------
app.include_router(api)
app.add_middleware(CORSMiddleware, allow_credentials=True,
                   allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
                   allow_methods=["*"], allow_headers=["*"])

@app.on_event("startup")
async def startup():
    try:
        init_storage()
        logger.info("Storage initialized")
    except Exception as e:
        logger.error(f"Storage init failed: {e}")
    await db.users.create_index("email", unique=True)
    await db.guests.create_index("slug")
    await db.subscribers.create_index("email", unique=True)
    # seed owner
    admin_email = os.environ["ADMIN_EMAIL"].lower()
    admin_pw = os.environ["ADMIN_PASSWORD"]
    existing = await db.users.find_one({"email": admin_email})
    if not existing:
        await db.users.insert_one({"id": new_id(), "email": admin_email, "name": "Kalyan (Owner)",
                                   "role": "owner", "password_hash": hash_pw(admin_pw), "created_at": iso()})
    elif not verify_pw(admin_pw, existing["password_hash"]):
        await db.users.update_one({"email": admin_email}, {"$set": {"password_hash": hash_pw(admin_pw)}})
    await get_settings_doc()
    await seed_data()

async def seed_data():
    if await db.guests.count_documents({}) > 0:
        return
    samples = [
        ("Dr. K. Srinivas", "AI Researcher & Tech Founder", "Technology",
         "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
         "How AI Will Change Telugu Education",
         "కృత్రిమ మేధ తెలుగు విద్యను ఎలా మారుస్తుంది",
         "Dr. Srinivas explains how AI tutors can teach rural students in their mother tongue, and why Telugu-language models matter for the next generation.",
         "డా. శ్రీనివాస్ గ్రామీణ విద్యార్థులకు మాతృభాషలో ఎలా బోధించవచ్చో వివరిస్తారు.",
         "https://images.unsplash.com/photo-1638823479047-3e79058c6e24?crop=entropy&cs=srgb&fm=jpg&q=85&w=800", True, True),
        ("Ananya Rao", "Independent Film Producer", "Cinema",
         "https://youtu.be/9bZkp7q19f0",
         "The Business of Telugu Indie Cinema",
         "తెలుగు ఇండీ సినిమా వ్యాపారం",
         "Ananya breaks down how independent films get funded, distributed, and discovered in a market dominated by big studios.",
         "అనన్య స్వతంత్ర చిత్రాలు ఎలా నిధులు పొందుతాయో వివరిస్తారు.",
         "https://images.unsplash.com/photo-1725033489648-a819750348eb?crop=entropy&cs=srgb&fm=jpg&q=85&w=800", True, False),
        ("Vikramaditya V.", "Political Analyst & Journalist", "Society",
         "https://www.youtube.com/watch?v=3JZ_D3ELwOQ",
         "Reading Between the Headlines",
         "వార్తల వెనుక నిజాలు",
         "A veteran journalist shares how to read news critically and spot misinformation in the age of WhatsApp forwards.",
         "ఒక అనుభవజ్ఞుడైన జర్నలిస్ట్ వార్తలను విమర్శనాత్మకంగా ఎలా చదవాలో పంచుకుంటారు.",
         "https://images.unsplash.com/photo-1589386417686-0d34b5903d23?crop=entropy&cs=srgb&fm=jpg&q=85&w=800", True, False),
        ("Rajesh Varma", "SaaS Entrepreneur", "Business",
         "https://www.youtube.com/watch?v=L_jWHffIx5E",
         "From Hyderabad to Global SaaS",
         "హైదరాబాద్ నుండి గ్లోబల్ SaaS వరకు",
         "Rajesh shares his journey building a software company from Hyderabad that now serves customers in 40 countries.",
         "రాజేష్ హైదరాబాద్ నుండి సాఫ్ట్‌వేర్ కంపెనీని నిర్మించిన ప్రయాణాన్ని పంచుకుంటారు.",
         "https://images.unsplash.com/photo-1716703741458-417a8d58f20e?crop=entropy&cs=srgb&fm=jpg&q=85&w=800", True, False),
        ("Dr. Padma Latha", "Pediatrician & Author", "Health",
         "https://www.youtube.com/watch?v=fJ9rUzIMcZQ",
         "Raising Healthy Kids the Simple Way",
         "ఆరోగ్యకరమైన పిల్లలను పెంచడం",
         "Dr. Padma answers common parenting questions about nutrition, screen time, and childhood illness in plain Telugu.",
         "డా. పద్మ పోషణ, స్క్రీన్ టైమ్ గురించి సాధారణ ప్రశ్నలకు సమాధానాలు ఇస్తారు.",
         "https://images.unsplash.com/photo-1594824476967-48c8b964273f?crop=entropy&cs=srgb&fm=jpg&q=85&w=800", True, False),
        ("Suresh Babu", "Financial Advisor", "Money",
         "https://www.youtube.com/watch?v=kJQP7kiw5Fk",
         "Smart Money Habits for Families",
         "కుటుంబాల కోసం స్మార్ట్ డబ్బు అలవాట్లు",
         "Suresh explains saving, SIPs, and avoiding common financial traps — all in simple, relatable Telugu.",
         "సురేష్ పొదుపు, SIP లు మరియు ఆర్థిక ఉచ్చులను నివారించడం గురించి వివరిస్తారు.",
         "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=srgb&fm=jpg&q=85&w=800", False, False),
    ]
    for i, s in enumerate(samples):
        name, desig, topic, yt, ten, tte, sen, ste, photo, feat, pin = s
        gid = new_id()
        await db.guests.insert_one({
            "id": gid, "slug": f"{slugify(name)}-{gid[:6]}", "name": name, "designation": desig,
            "topic": topic, "youtube_url": yt, "photo_url": photo, "title_en": ten, "title_te": tte,
            "synopsis_en": sen, "synopsis_te": ste, "bio": f"{name} is a respected {desig.lower()}.",
            "episode_date": (now() - timedelta(days=i*7)).date().isoformat(),
            "tags": [topic], "featured": feat, "pinned": pin,
            "status": "draft" if name == "Suresh Babu" else "published",
            "te_reviewed": True, "order": i, "impressions": 0, "created_at": iso()})
    # sample ads
    today = now().date().isoformat(); end = (now()+timedelta(days=60)).date().isoformat()
    await db.ads.insert_one({"id": new_id(), "advertiser": "Shine Studios", "headline": "Record your podcast at Shine Studios",
        "image_url": "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?crop=entropy&cs=srgb&fm=jpg&q=85&w=1200",
        "destination_url": "https://example.com/shine", "slots": ["home-top"], "start_date": today,
        "end_date": end, "status": "active", "priority": 5, "language": "all", "embed_code": "",
        "embed_enabled": False, "impressions": 0, "clicks": 0, "created_at": iso()})
    await db.ads.insert_one({"id": new_id(), "advertiser": "Telugu Books Co", "headline": "Discover Telugu literature online",
        "image_url": "https://images.unsplash.com/photo-1512820790803-83ca734da794?crop=entropy&cs=srgb&fm=jpg&q=85&w=1200",
        "destination_url": "https://example.com/books", "slots": ["home-mid", "guests-grid"], "start_date": today,
        "end_date": end, "status": "active", "priority": 3, "language": "all", "embed_code": "",
        "embed_enabled": False, "impressions": 0, "clicks": 0, "created_at": iso()})

@app.on_event("shutdown")
async def shutdown():
    client.close()
