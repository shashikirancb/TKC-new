# The Kalyan Chronicles — PRD

## Original Problem Statement
Build a responsive, mobile-first, bilingual (English / తెలుగు) website with an admin panel for "The Kalyan Chronicles", a Telugu podcast & interview brand. Site goals in order: (1) drive visitors to the YouTube channel/videos, (2) drive visitors to the separate E-Paper site, (3) attract advertisers. Track clicks on every YouTube, E-Paper and Advertise button.

## Architecture
- **Frontend**: React 19 + Vite + Tailwind v4 + shadcn/ui. Context-based bilingual (EN/TE) + light/dark theme (persisted in localStorage). Fonts: Baloo Tammudu 2 (headings), Inter (body), Noto Sans Telugu (Telugu, line-height 1.7).
- **Backend**: FastAPI + MongoDB (UUID string ids). All routes `/api` prefixed.
- **Auth**: JWT Bearer (email+password), roles owner/editor, 8h session. Token in localStorage `kc_token`.
- **Integrations**: Emergent LLM key (gpt-5.4) for EN→TE translation; Emergent managed Resend for transactional email.
- Brand kit colors applied via CSS variables; 20px card radius, 14px buttons, pill chips.

## User Personas
- **Visitor**: watches episodes, reads E-Paper, applies to be a guest, subscribes to newsletter.
- **Advertiser**: views rate card, submits inquiry.
- **Owner/Editor (admin)**: manages guests, ads, applications, newsletter, settings, views analytics.

## Core Requirements (static)
Public: Home (hero latest episode, ad slots, about, guests carousel, e-paper band, register form, newsletter), All Guests (search/filter/sort/pagination + detail pages with EN/TE synopsis tabs, share, related, schema.org VideoObject), Advertise (audience, reach, rate card, media kit, inquiry form). Admin: dashboard, guests manager (YouTube validate + live preview + AI translate + review-gate + bulk/duplicate), applications inbox, newsletter, ads manager (rotation by priority, reporting + CSV), ad inquiries, settings. Analytics events. Cookie notice.

## Implemented (2026-06)
- Full public site + all forms, bilingual toggle, light/dark, cookie notice. ✅
- Full admin panel with all 7 sections, JWT auth + role gating, AI translate, ad reporting chart + CSV. ✅
- First-party analytics events + dashboard. ✅
- Transactional emails (guest confirmation, newsletter double opt-in, admin notifications). ✅
- Seed data: 6 guests (5 published + 1 draft), 2 ad campaigns, full demo text. ✅
- Tested: backend 96.7%, frontend 100%.

## Backlog / Remaining (P1/P2)
- P1: CSV import for guests; drag-to-reorder UI for featured guests (reorder API exists).
- P1: Optional 2FA for admin; brute-force lockout (login endpoint).
- P2: Newsletter compose/send + scheduling; media-kit PDF upload via object storage; image upload with crop for guest photos (currently URL).
- P2: sitemap.xml / robots.txt / hreflang tags; privacy & terms page content.
- P2: Split server.py into routers for maintainability.

## Admin
- Owner: shashikirancb@gmail.com / Kalyan@2026 (see /app/memory/test_credentials.md)
