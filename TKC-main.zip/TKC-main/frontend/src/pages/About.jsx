import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Youtube, Radio, Mic, ArrowRight } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { openExternal } from "@/lib/api";
import { PublicLayout } from "@/components/PublicLayout";
import { siteImg } from "@/lib/assets";
import { ABOUT_DEFAULTS } from "@/lib/aboutContent";

export default function About() {
  const { tr, lang, pick, settings } = useApp();
  const d = ABOUT_DEFAULTS[lang] || ABOUT_DEFAULTS.en;
  const g = (base) => pick(settings, base) || d[base];
  const yt = settings?.youtube_channel_url;

  useEffect(() => { document.title = `${tr("nav_about")} · ${settings?.site_name || "The Kalyan Chronicles"}`; }, [tr, settings]);

  const hostParas = (g("about_host_body") || "").split("\n\n").filter(Boolean);
  const radioParas = (g("about_radio_body") || "").split("\n\n").filter(Boolean);

  return (
    <PublicLayout>
      {/* 1. HERO */}
      <section className="bg-midnight text-cream relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-[26rem] h-[26rem] rounded-full bg-gold/10 blur-3xl" />
        <div className="absolute -bottom-28 -left-24 w-[26rem] h-[26rem] rounded-full bg-teal/10 blur-3xl" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 lg:py-24 grid lg:grid-cols-2 gap-12 items-center relative">
          <div className="anim-rise">
            <span className="uppercase text-xs tracking-[0.25em] font-bold text-gold">{settings?.site_name || "The Kalyan Chronicles"}</span>
            <h1 className="font-heading font-extrabold text-4xl sm:text-5xl lg:text-6xl mt-3 leading-[1.1]" data-testid="about-hero-heading">{g("about_hero_heading")}</h1>
            <p className="text-cream/75 mt-5 text-base sm:text-lg leading-relaxed max-w-xl">{g("about_hero_desc")}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/guests" data-testid="about-hero-cta"
                className="flex items-center gap-2 bg-gold hover:bg-[#E5A72E] text-midnight font-bold rounded-[14px] px-6 py-3.5 transition-all hover:scale-[1.02] shadow-[0_4px_20px_rgba(244,183,63,0.3)]">
                {g("about_hero_cta")} <ArrowRight size={18} />
              </Link>
              <button onClick={() => openExternal(yt, "click_youtube", { source: "about_hero" })}
                className="flex items-center gap-2 border-2 border-cream/25 hover:border-gold text-cream font-semibold rounded-[14px] px-6 py-3.5 transition-colors">
                <Youtube size={18} /> {tr("watch_youtube")}
              </button>
            </div>
          </div>
          <div className="relative anim-rise" style={{ animationDelay: "120ms" }}>
            <div className="absolute inset-0 -rotate-3 rounded-[24px] bg-gold/20" />
            <img src={siteImg(settings, "about_hero")} alt="The Kalyan Chronicles podcast studio" loading="lazy"
              className="relative rounded-[24px] w-full object-cover shadow-[0_30px_60px_rgba(0,0,0,0.45)] border border-white/10" />
          </div>
        </div>
      </section>

      {/* 2. MEET THE HOST */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16 lg:py-24 grid lg:grid-cols-2 gap-12 items-center">
        <div className="relative">
          <img src={siteImg(settings, "about_host")} alt="Kalyan K Bharath, host of The Kalyan Chronicles" loading="lazy"
            className="rounded-[24px] w-full object-cover shadow-[0_24px_48px_rgba(15,47,99,0.18)]" />
          <div className="absolute -bottom-5 -right-3 bg-gold text-midnight font-heading font-bold rounded-[16px] px-5 py-3 shadow-lg hidden sm:block">Kalyan K Bharath</div>
        </div>
        <div>
          <span className="uppercase text-xs tracking-[0.25em] font-bold text-teal">{tr("meet_host")}</span>
          <h2 className="font-heading font-bold text-3xl sm:text-4xl mt-2" data-testid="about-host-heading">{g("about_host_heading")}</h2>
          <div className="mt-5 space-y-4">
            {hostParas.map((p, i) => <p key={i} className="text-muted-foreground leading-relaxed text-base sm:text-lg">{p}</p>)}
          </div>
          <button onClick={() => openExternal(yt, "click_youtube", { source: "about_host" })} data-testid="about-host-youtube-btn"
            className="mt-7 flex items-center gap-2 bg-navy hover:bg-midnight text-white font-semibold rounded-[14px] px-6 py-3.5 transition-all hover:scale-[1.02]">
            <Youtube size={18} /> {tr("watch_youtube")}
          </button>
        </div>
      </section>

      {/* 3. THE RADIO JOURNEY */}
      <section className="bg-card/50 border-y border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 lg:py-24 grid lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <span className="uppercase text-xs tracking-[0.25em] font-bold text-gold flex items-center gap-2"><Radio size={15} /> {tr("radio_journey")}</span>
            <h2 className="font-heading font-bold text-3xl sm:text-4xl mt-2" data-testid="about-radio-heading">{g("about_radio_heading")}</h2>
            <div className="mt-5 space-y-4">
              {radioParas.map((p, i) => <p key={i} className="text-muted-foreground leading-relaxed text-base sm:text-lg">{p}</p>)}
            </div>
          </div>
          <div className="order-1 lg:order-2 relative">
            <img src={siteImg(settings, "about_radio")} alt="Radio broadcast microphone in a studio" loading="lazy"
              className="rounded-[24px] w-full aspect-[4/3] object-cover shadow-[0_24px_48px_rgba(15,47,99,0.18)]" />
            <div className="absolute top-4 left-4 bg-midnight/80 backdrop-blur text-cream rounded-full px-4 py-2 text-xs font-bold flex items-center gap-2 border border-white/10">
              <Mic size={14} className="text-gold" /> On Air · UK
            </div>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
