import { useState } from "react";
import { Users, TrendingUp, Download, Loader2, CheckCircle2, FileText } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { api, formatApiError } from "@/lib/api";
import { PublicLayout } from "@/components/PublicLayout";
import { toast } from "sonner";

const F = "w-full rounded-[12px] px-4 py-2.5 bg-background border border-border focus:outline-none focus:border-gold text-sm";

export default function Advertise() {
  const { tr, pick, settings } = useApp();
  const [f, setF] = useState({ company: "", contact_name: "", email: "", phone: "", budget: "", ad_type: "", message: "", honeypot: "" });
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.post("/ad-inquiries", f);
      setDone(true);
      toast.success(tr("inquiry_success"));
    } catch (er) { toast.error(formatApiError(er.response?.data?.detail)); }
    finally { setBusy(false); }
  };

  const rates = settings?.rate_card || [];
  const reach = settings?.advertise_reach || [];

  return (
    <PublicLayout>
      <section className="bg-midnight text-cream py-16 relative overflow-hidden">
        <div className="absolute -bottom-20 -left-20 w-96 h-96 rounded-full bg-teal/10 blur-3xl" />
        <div className="max-w-5xl mx-auto px-4 sm:px-6 relative">
          <span className="uppercase text-xs tracking-[0.2em] font-bold text-gold">{tr("advertise_with_us")}</span>
          <h1 className="font-heading font-extrabold text-4xl sm:text-5xl lg:text-6xl mt-2">{tr("advertise_title")}</h1>
          <p className="text-cream/75 mt-3 text-lg max-w-2xl">{tr("advertise_sub")}</p>
          <div className="grid grid-cols-3 gap-4 mt-10 max-w-2xl">
            {reach.map((r, i) => (
              <div key={i} className="bg-white/5 rounded-[16px] p-4 border border-white/10" data-testid={`reach-stat-${i}`}>
                <div className="font-heading font-extrabold text-2xl sm:text-3xl text-gold">{r.value}</div>
                <div className="text-xs text-cream/60 mt-1">{pick(r, "label") || r.label || r.label_en}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 sm:px-6 py-14 grid md:grid-cols-2 gap-10">
        <div>
          <h2 className="font-heading font-bold text-2xl flex items-center gap-2"><Users size={22} className="text-teal" /> {tr("who_watches")}</h2>
          <p className="mt-3 text-muted-foreground leading-relaxed">{pick(settings, "advertise_audience")}</p>
        </div>
        <div>
          <h2 className="font-heading font-bold text-2xl flex items-center gap-2"><TrendingUp size={22} className="text-teal" /> {tr("why_telugu")}</h2>
          <p className="mt-3 text-muted-foreground leading-relaxed">{tr("why_telugu_text")}</p>
        </div>
      </section>

      {/* rate card */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 py-6">
        <h2 className="font-heading font-bold text-2xl sm:text-3xl mb-6">{tr("ad_formats")}</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          {rates.map((r, i) => (
            <div key={i} className="rounded-[20px] bg-card border border-border p-5 flex items-center justify-between shadow-sm hover:border-gold transition-colors" data-testid={`rate-card-${i}`}>
              <span className="font-semibold">{r.format}</span>
              <span className="text-sm font-bold text-teal">{r.price}</span>
            </div>
          ))}
        </div>
        {settings?.media_kit_url && (
          <a href={settings.media_kit_url} target="_blank" rel="noopener noreferrer" data-testid="media-kit-btn"
            className="mt-6 inline-flex items-center gap-2 bg-navy text-white font-semibold rounded-[14px] px-5 py-3 hover:scale-[1.02] transition-all">
            <Download size={18} /> {tr("media_kit")}
          </a>
        )}
      </section>

      {/* inquiry form */}
      <section className="max-w-3xl mx-auto px-4 sm:px-6 py-14">
        <div className="bg-card border border-border rounded-[20px] p-6 sm:p-8 shadow-[0_12px_32px_rgba(15,47,99,0.08)]">
          <h2 className="font-heading font-bold text-2xl mb-6 flex items-center gap-2"><FileText size={22} className="text-teal" /> {tr("inquiry_title")}</h2>
          {done ? (
            <div className="text-center py-10" data-testid="inquiry-success">
              <CheckCircle2 size={56} className="mx-auto text-teal mb-4" />
              <p className="text-lg font-semibold">{tr("inquiry_success")}</p>
            </div>
          ) : (
            <form onSubmit={submit} className="grid sm:grid-cols-2 gap-4" data-testid="ad-inquiry-form">
              <input type="text" tabIndex={-1} value={f.honeypot} onChange={set("honeypot")} className="hidden" aria-hidden />
              <input className={F} required placeholder={tr("company")} value={f.company} onChange={set("company")} data-testid="inq-company" />
              <input className={F} required placeholder={tr("contact_name")} value={f.contact_name} onChange={set("contact_name")} data-testid="inq-name" />
              <input className={F} required type="email" placeholder={tr("email")} value={f.email} onChange={set("email")} data-testid="inq-email" />
              <input className={F} placeholder={tr("phone")} value={f.phone} onChange={set("phone")} data-testid="inq-phone" />
              <input className={F} placeholder={tr("budget")} value={f.budget} onChange={set("budget")} data-testid="inq-budget" />
              <select className={F} value={f.ad_type} onChange={set("ad_type")} data-testid="inq-adtype">
                <option value="">{tr("ad_type")}</option>
                {rates.map((r, i) => <option key={i} value={r.format}>{r.format}</option>)}
              </select>
              <textarea className={F + " sm:col-span-2 min-h-[100px]"} placeholder={tr("message")} value={f.message} onChange={set("message")} data-testid="inq-message" />
              <button type="submit" disabled={busy} data-testid="inq-submit"
                className="sm:col-span-2 bg-gold hover:bg-[#E5A72E] text-midnight font-bold rounded-[14px] px-6 py-3 flex items-center justify-center gap-2 disabled:opacity-60 transition-all hover:scale-[1.01]">
                {busy && <Loader2 size={18} className="animate-spin" />} {tr("submit")}
              </button>
            </form>
          )}
        </div>
      </section>
    </PublicLayout>
  );
}
