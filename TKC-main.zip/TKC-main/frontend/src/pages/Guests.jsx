import { useEffect, useState, useCallback } from "react";
import { Search } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { api } from "@/lib/api";
import { PublicLayout } from "@/components/PublicLayout";
import { GuestCard } from "@/components/GuestCard";
import { AdSlot } from "@/components/AdSlot";

export default function Guests() {
  const { tr, settings } = useApp();
  const [q, setQ] = useState("");
  const [topic, setTopic] = useState("all");
  const [sort, setSort] = useState("newest");
  const [data, setData] = useState({ items: [], total: 0, pages: 1 });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const topics = ["all", ...(settings?.topics || [])];

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/guests", { params: { q, topic, sort, page, limit: 9 } });
      setData(data);
    } finally { setLoading(false); }
  }, [q, topic, sort, page]);

  useEffect(() => { const d = setTimeout(load, 250); return () => clearTimeout(d); }, [load]);
  useEffect(() => { setPage(1); }, [q, topic, sort]);

  return (
    <PublicLayout>
      <section className="bg-midnight text-cream py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h1 className="font-heading font-extrabold text-4xl sm:text-5xl">{tr("guests_title")}</h1>
          <p className="text-cream/70 mt-2">{tr("guests_intro")}</p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-4 lg:items-center mb-6">
          <div className="relative flex-1">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={tr("search_ph")} data-testid="guest-search-input"
              className="w-full rounded-[14px] pl-10 pr-4 py-3 bg-card border border-border focus:outline-none focus:border-gold" />
          </div>
          <select value={sort} onChange={(e) => setSort(e.target.value)} data-testid="guest-sort-select"
            className="rounded-[14px] px-4 py-3 bg-card border border-border focus:outline-none focus:border-gold">
            <option value="newest">{tr("sort_newest")}</option>
            <option value="az">{tr("sort_az")}</option>
          </select>
        </div>

        <div className="flex flex-wrap gap-2 mb-8">
          {topics.map((t) => (
            <button key={t} onClick={() => setTopic(t)} data-testid={`topic-chip-${t}`}
              className={`rounded-full px-4 py-1.5 text-xs font-semibold border transition-all ${topic === t ? "bg-gold text-midnight border-gold" : "border-border hover:border-gold"}`}>
              {t === "all" ? tr("all_topics") : t}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => <div key={i} className="rounded-[20px] bg-card border border-border h-80 animate-pulse" />)}
          </div>
        ) : data.items.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground" data-testid="guests-empty">{tr("no_results")}</div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="guests-grid">
            {data.items.map((g, i) => (
              <GuestCard key={g.id} guest={g} index={i} />
            ))}
            {data.items.length >= 9 && <AdSlot slot="guests-grid" className="aspect-video sm:col-span-1" />}
          </div>
        )}

        {data.pages > 1 && (
          <div className="flex justify-center gap-2 mt-10">
            {[...Array(data.pages)].map((_, i) => (
              <button key={i} onClick={() => setPage(i + 1)} data-testid={`page-${i + 1}`}
                className={`h-10 w-10 rounded-full font-semibold text-sm transition-colors ${page === i + 1 ? "bg-navy text-white" : "bg-card border border-border hover:border-gold"}`}>{i + 1}</button>
            ))}
          </div>
        )}
      </section>
    </PublicLayout>
  );
}
