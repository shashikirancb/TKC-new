import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { Play, Youtube, ArrowLeft, Share2, Copy, Calendar, Tag } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { api, openExternal } from "@/lib/api";
import { PublicLayout } from "@/components/PublicLayout";
import { GuestCard } from "@/components/GuestCard";
import { toast } from "sonner";

export default function GuestDetail() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { tr, lang } = useApp();
  const [g, setG] = useState(null);
  const [tab, setTab] = useState("en");
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    setTab(lang);
    api.get(`/guests/${slug}`).then(({ data }) => setG(data)).catch(() => setNotFound(true));
  }, [slug]);

  useEffect(() => {
    if (g) {
      document.title = `${g.title_en || g.name} — The Kalyan Chronicles`;
      const meta = document.querySelector('meta[name="description"]');
      if (meta) meta.content = (g.synopsis_en || "").slice(0, 150);
      const ld = document.createElement("script");
      ld.type = "application/ld+json";
      ld.text = JSON.stringify({
        "@context": "https://schema.org", "@type": "VideoObject",
        name: g.title_en || g.name, description: g.synopsis_en,
        thumbnailUrl: g.thumbnail || g.yt_thumbnail, uploadDate: g.episode_date,
        embedUrl: g.video_id ? `https://www.youtube.com/embed/${g.video_id}` : undefined,
      });
      ld.id = "guest-ld"; document.getElementById("guest-ld")?.remove();
      document.head.appendChild(ld);
      return () => document.getElementById("guest-ld")?.remove();
    }
  }, [g]);

  if (notFound) return <PublicLayout><div className="max-w-3xl mx-auto px-4 py-28 text-center"><p className="text-xl">Guest not found.</p><Link to="/guests" className="text-navy dark:text-gold font-semibold mt-4 inline-block">← Back to guests</Link></div></PublicLayout>;
  if (!g) return <PublicLayout><div className="max-w-5xl mx-auto px-4 py-16"><div className="h-96 bg-card rounded-[20px] animate-pulse" /></div></PublicLayout>;

  const synEn = g.synopsis_en, synTe = g.synopsis_te;
  const shareUrl = window.location.href;
  const copy = () => { navigator.clipboard.writeText(shareUrl); toast.success(tr("copied")); };
  const whatsapp = () => window.open(`https://wa.me/?text=${encodeURIComponent((g.title_en || g.name) + " " + shareUrl)}`, "_blank", "noopener");

  return (
    <PublicLayout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <button onClick={() => navigate("/guests")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-navy dark:hover:text-gold mb-6" data-testid="back-to-guests">
          <ArrowLeft size={16} /> {tr("nav_guests")}
        </button>

        <button onClick={() => openExternal(g.youtube_url, "click_youtube", { video_id: g.video_id, source: "detail" })}
          data-testid="detail-thumbnail" className="relative w-full aspect-video rounded-[20px] overflow-hidden shadow-xl group block bg-midnight">
          <img src={g.thumbnail || g.yt_thumbnail} alt={g.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
          <div className="absolute inset-0 bg-midnight/25 flex items-center justify-center">
            <div className="h-16 w-16 rounded-full bg-gold flex items-center justify-center group-hover:scale-110 transition-transform"><Play size={28} className="text-midnight ml-1" fill="currentColor" /></div>
          </div>
        </button>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          <span className="bg-teal/15 text-teal border border-teal/30 text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1"><Tag size={12} />{g.topic}</span>
          <span className="text-xs text-muted-foreground flex items-center gap-1"><Calendar size={13} />{g.episode_date}</span>
        </div>

        <h1 className={`font-heading font-extrabold text-3xl sm:text-4xl mt-3 ${lang === "te" ? "lang-te" : ""}`}>
          {(lang === "te" && g.title_te) ? g.title_te : g.title_en}
        </h1>
        <p className="mt-2 text-lg font-semibold text-teal">{g.name}</p>
        <p className="text-muted-foreground">{g.designation}</p>

        <div className="flex flex-wrap gap-3 mt-6">
          <button onClick={() => openExternal(g.youtube_url, "click_youtube", { video_id: g.video_id, source: "detail-btn" })}
            data-testid="detail-watch-youtube-btn"
            className="flex items-center gap-2 bg-gold hover:bg-[#E5A72E] text-midnight font-bold rounded-[14px] px-6 py-3 transition-all hover:scale-[1.02] shadow-[0_4px_24px_rgba(244,183,63,0.35)]">
            <Youtube size={20} /> {tr("watch_youtube")}
          </button>
          <button onClick={whatsapp} data-testid="share-whatsapp" className="flex items-center gap-2 border border-border rounded-[14px] px-4 py-3 font-semibold hover:border-gold transition-colors"><Share2 size={16} /> {tr("whatsapp")}</button>
          <button onClick={copy} data-testid="share-copy" className="flex items-center gap-2 border border-border rounded-[14px] px-4 py-3 font-semibold hover:border-gold transition-colors"><Copy size={16} /> {tr("copy_link")}</button>
        </div>

        {/* synopsis tabs */}
        <div className="mt-10">
          <div className="flex gap-2 border-b border-border">
            <button onClick={() => setTab("en")} data-testid="synopsis-tab-en" className={`px-4 py-2 font-semibold text-sm -mb-px border-b-2 transition-colors ${tab === "en" ? "border-gold text-navy dark:text-gold" : "border-transparent text-muted-foreground"}`}>English</button>
            {synTe && <button onClick={() => setTab("te")} data-testid="synopsis-tab-te" className={`px-4 py-2 font-semibold text-sm -mb-px border-b-2 transition-colors ${tab === "te" ? "border-gold text-navy dark:text-gold" : "border-transparent text-muted-foreground"}`}>తెలుగు</button>}
          </div>
          <div className={`mt-5 leading-relaxed text-muted-foreground ${tab === "te" ? "lang-te" : ""}`} data-testid="synopsis-content">
            <p>{tab === "te" ? synTe : synEn}</p>
            {g.bio && <p className="mt-4 text-sm"><strong className="text-foreground">Bio:</strong> {g.bio}</p>}
          </div>
        </div>

        {/* related */}
        {g.related?.length > 0 && (
          <div className="mt-14">
            <h2 className="font-heading font-bold text-2xl mb-6">{tr("related")}</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {g.related.map((r, i) => <GuestCard key={r.id} guest={r} index={i} />)}
            </div>
          </div>
        )}
      </div>
    </PublicLayout>
  );
}
