import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { formatApiError } from "@/lib/api";
import { Loader2, Lock } from "lucide-react";
import { LOGO_URL } from "@/lib/assets";

export default function AdminLogin() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr("");
    try {
      await login(email, password);
      navigate("/admin");
    } catch (er) {
      setErr(formatApiError(er.response?.data?.detail) || "Login failed");
    } finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen bg-midnight flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-card rounded-[20px] p-8 shadow-2xl anim-float">
        <img src={LOGO_URL} alt="logo" className="h-16 mx-auto object-contain mb-4" />
        <h1 className="font-heading font-bold text-2xl text-center flex items-center justify-center gap-2"><Lock size={20} className="text-gold" /> Admin Login</h1>
        <form onSubmit={submit} className="mt-6 space-y-4" data-testid="admin-login-form">
          <input type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} data-testid="login-email"
            className="w-full rounded-[12px] px-4 py-3 bg-background border border-border focus:outline-none focus:border-gold" />
          <input type="password" required placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} data-testid="login-password"
            className="w-full rounded-[12px] px-4 py-3 bg-background border border-border focus:outline-none focus:border-gold" />
          {err && <p className="text-sm text-destructive" data-testid="login-error">{err}</p>}
          <button type="submit" disabled={busy} data-testid="login-submit"
            className="w-full bg-gold hover:bg-[#E5A72E] text-midnight font-bold rounded-[14px] px-6 py-3 flex items-center justify-center gap-2 disabled:opacity-60">
            {busy && <Loader2 size={18} className="animate-spin" />} Sign in
          </button>
        </form>
      </div>
    </div>
  );
}
