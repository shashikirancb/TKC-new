import { useEffect, useState, useCallback } from "react";
import { api } from "@/lib/api";
import { Download, Mail, Plus } from "lucide-react";
import { toast } from "sonner";

const badge = "text-xs px-2 py-0.5 rounded-full";

function toCSV(rows) {
  if (!rows.length) return "";
  const keys = Object.keys(rows[0]);
  const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [keys.join(","), ...rows.map((r) => keys.map((k) => esc(r[k])).join(","))].join("\n");
}
function download(name, text) {
  const blob = new Blob([text], { type: "text/csv" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; a.click();
}

export function Applications() {
  const [rows, setRows] = useState([]);
  const [status, setStatus] = useState("all");
  const [q, setQ] = useState("");
  const load = useCallback(async () => { const { data } = await api.get("/admin/applications", { params: { status, q } }); setRows(data); }, [status, q]);
  useEffect(() => { const d = setTimeout(load, 200); return () => clearTimeout(d); }, [load]);
  const STATUSES = ["new", "shortlisted", "contacted", "scheduled", "rejected"];
  const upd = async (id, patch) => { await api.put(`/admin/applications/${id}`, patch); load(); };

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="font-heading font-bold text-3xl">Guest Applications</h1>
        <button onClick={() => download("applications.csv", toCSV(rows))} className="flex items-center gap-2 border border-border rounded-[14px] px-4 py-2 text-sm font-semibold"><Download size={16} /> Export CSV</button>
      </div>
      <div className="flex gap-3 mb-4">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search…" className="flex-1 rounded-[12px] px-3 py-2 bg-background border border-border text-sm" data-testid="app-search" />
        <select value={status} onChange={(e) => setStatus(e.target.value)} className="rounded-[12px] px-3 py-2 bg-background border border-border text-sm">
          <option value="all">All</option>{STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>
      <div className="space-y-3">
        {rows.map((a) => (
          <div key={a.id} className="rounded-[20px] bg-card border border-border p-4" data-testid={`application-${a.id}`}>
            <div className="flex justify-between flex-wrap gap-2">
              <div>
                <p className="font-semibold">{a.name} <span className="text-muted-foreground text-sm">· {a.profession} @ {a.organisation}</span></p>
                <p className="text-sm text-muted-foreground">{a.email} · {a.phone} · {a.city}</p>
                <p className="text-sm mt-1"><span className={badge + " bg-teal/15 text-teal"}>{a.expertise}</span> <span className="text-muted-foreground">Topics: {a.topics}</span></p>
                <p className="text-sm text-muted-foreground mt-1">{a.bio}</p>
              </div>
              <div className="flex flex-col gap-2 items-end">
                <select value={a.status} onChange={(e) => upd(a.id, { status: e.target.value })} className="rounded-[12px] px-3 py-1.5 bg-background border border-border text-xs" data-testid={`app-status-${a.id}`}>
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
                <a href={`mailto:${a.email}`} className="flex items-center gap-1 text-xs text-navy dark:text-gold font-semibold"><Mail size={13} /> Email</a>
              </div>
            </div>
            <input defaultValue={a.notes} onBlur={(e) => upd(a.id, { notes: e.target.value })} placeholder="Internal notes…" className="mt-3 w-full rounded-[12px] px-3 py-2 bg-background border border-border text-sm" />
          </div>
        ))}
        {rows.length === 0 && <div className="text-center py-16 text-muted-foreground">No applications.</div>}
      </div>
    </div>
  );
}

export function NewsletterAdmin() {
  const [rows, setRows] = useState([]);
  const [status, setStatus] = useState("all");
  const [email, setEmail] = useState("");
  const load = useCallback(async () => { const { data } = await api.get("/admin/subscribers", { params: { status } }); setRows(data); }, [status]);
  useEffect(() => { load(); }, [load]);
  const add = async () => { if (!email) return; await api.post("/admin/subscribers", { email }); setEmail(""); toast.success("Added"); load(); };
  const color = (s) => s === "confirmed" ? "bg-teal/20 text-teal" : s === "pending" ? "bg-gold/20 text-navy dark:text-gold" : "bg-muted text-muted-foreground";

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="font-heading font-bold text-3xl">Newsletter</h1>
        <button onClick={() => download("subscribers.csv", toCSV(rows))} className="flex items-center gap-2 border border-border rounded-[14px] px-4 py-2 text-sm font-semibold"><Download size={16} /> Export CSV</button>
      </div>
      <div className="flex gap-3 mb-4 flex-wrap">
        <select value={status} onChange={(e) => setStatus(e.target.value)} className="rounded-[12px] px-3 py-2 bg-background border border-border text-sm">
          <option value="all">All</option><option value="confirmed">Confirmed</option><option value="pending">Pending</option><option value="unsubscribed">Unsubscribed</option>
        </select>
        <div className="flex gap-2 flex-1 min-w-[220px]">
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Add subscriber email" className="flex-1 rounded-[12px] px-3 py-2 bg-background border border-border text-sm" data-testid="add-sub-email" />
          <button onClick={add} className="flex items-center gap-1 bg-navy text-white rounded-[12px] px-3 text-sm font-semibold"><Plus size={16} /> Add</button>
        </div>
      </div>
      <div className="rounded-[20px] bg-card border border-border overflow-hidden overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-background text-left"><tr><th className="p-3">Email</th><th className="p-3">Name</th><th className="p-3">Lang</th><th className="p-3">Status</th></tr></thead>
          <tbody>{rows.map((s) => (
            <tr key={s.id} className="border-t border-border"><td className="p-3">{s.email}</td><td className="p-3">{s.name || "—"}</td><td className="p-3">{s.language}</td><td className="p-3"><span className={badge + " " + color(s.status)}>{s.status}</span></td></tr>
          ))}</tbody>
        </table>
        {rows.length === 0 && <div className="p-10 text-center text-muted-foreground">No subscribers.</div>}
      </div>
    </div>
  );
}

export function AdInquiriesAdmin() {
  const [rows, setRows] = useState([]);
  const load = useCallback(async () => { const { data } = await api.get("/admin/ad-inquiries"); setRows(data); }, []);
  useEffect(() => { load(); }, [load]);
  const STATUSES = ["new", "contacted", "negotiating", "won", "lost"];
  const upd = async (id, patch) => { await api.put(`/admin/ad-inquiries/${id}`, patch); load(); };
  return (
    <div>
      <h1 className="font-heading font-bold text-3xl mb-6">Ad Inquiries</h1>
      <div className="space-y-3">
        {rows.map((a) => (
          <div key={a.id} className="rounded-[20px] bg-card border border-border p-4" data-testid={`inquiry-${a.id}`}>
            <div className="flex justify-between flex-wrap gap-2">
              <div>
                <p className="font-semibold">{a.company} <span className="text-muted-foreground text-sm">· {a.contact_name}</span></p>
                <p className="text-sm text-muted-foreground">{a.email} · {a.phone} · Budget: {a.budget} · {a.ad_type}</p>
                <p className="text-sm mt-1">{a.message}</p>
              </div>
              <select value={a.status} onChange={(e) => upd(a.id, { status: e.target.value })} className="rounded-[12px] px-3 py-1.5 bg-background border border-border text-xs h-fit">
                {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
        ))}
        {rows.length === 0 && <div className="text-center py-16 text-muted-foreground">No inquiries.</div>}
      </div>
    </div>
  );
}
