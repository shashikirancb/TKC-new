import { useParams, useNavigate, Navigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { useApp } from "@/context/AppContext";
import { LayoutDashboard, Users, Inbox, Mail, Megaphone, MessageSquare, Settings as SettingsIcon, LogOut, Moon, Sun, ExternalLink } from "lucide-react";
import { LOGO_URL } from "@/lib/assets";
import Dashboard from "@/pages/admin/Dashboard";
import GuestsManager from "@/pages/admin/GuestsManager";
import AdsManager from "@/pages/admin/AdsManager";
import SettingsAdmin from "@/pages/admin/SettingsAdmin";
import { Applications, NewsletterAdmin, AdInquiriesAdmin } from "@/pages/admin/Sections";

const NAV = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "guests", label: "Guests", icon: Users },
  { id: "applications", label: "Applications", icon: Inbox },
  { id: "newsletter", label: "Newsletter", icon: Mail },
  { id: "ads", label: "Ads Manager", icon: Megaphone },
  { id: "inquiries", label: "Ad Inquiries", icon: MessageSquare },
  { id: "settings", label: "Settings", icon: SettingsIcon },
];

export default function Admin() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useApp();
  const { section = "dashboard" } = useParams();
  const navigate = useNavigate();

  if (user === null) return <div className="min-h-screen flex items-center justify-center bg-background">Loading…</div>;
  if (user === false) return <Navigate to="/login" replace />;

  const render = () => {
    switch (section) {
      case "guests": return <GuestsManager />;
      case "applications": return <Applications />;
      case "newsletter": return <NewsletterAdmin />;
      case "ads": return <AdsManager />;
      case "inquiries": return <AdInquiriesAdmin />;
      case "settings": return <SettingsAdmin user={user} />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-background flex">
      <aside className="w-16 lg:w-60 bg-midnight text-cream flex flex-col shrink-0 sticky top-0 h-screen">
        <div className="p-3 lg:p-4 border-b border-white/10 flex items-center gap-2">
          <img src={LOGO_URL} alt="logo" className="h-10 w-auto object-contain" />
          <span className="hidden lg:block font-heading font-bold text-sm text-gold leading-tight">Admin</span>
        </div>
        <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
          {NAV.map((n) => {
            const Icon = n.icon; const active = section === n.id;
            return (
              <button key={n.id} onClick={() => navigate(`/admin/${n.id}`)} data-testid={`admin-nav-${n.id}`}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-[12px] text-sm font-semibold transition-colors ${active ? "bg-gold text-midnight" : "hover:bg-white/10"}`}>
                <Icon size={18} className="shrink-0" /> <span className="hidden lg:block">{n.label}</span>
              </button>
            );
          })}
        </nav>
        <div className="p-2 border-t border-white/10 space-y-1">
          <button onClick={() => window.open("/", "_blank")} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-[12px] text-sm hover:bg-white/10"><ExternalLink size={18} /><span className="hidden lg:block">View site</span></button>
          <button onClick={toggleTheme} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-[12px] text-sm hover:bg-white/10">{theme === "light" ? <Moon size={18} /> : <Sun size={18} />}<span className="hidden lg:block">Theme</span></button>
          <button onClick={() => { logout(); navigate("/login"); }} data-testid="admin-logout" className="w-full flex items-center gap-3 px-3 py-2.5 rounded-[12px] text-sm hover:bg-destructive/20 text-red-300"><LogOut size={18} /><span className="hidden lg:block">Logout</span></button>
        </div>
      </aside>
      <main className="flex-1 min-w-0 overflow-x-hidden">
        <div className="p-4 sm:p-8">{render()}</div>
      </main>
    </div>
  );
}
