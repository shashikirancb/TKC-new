import { useEffect, useState } from "react";
import { api, formatApiError } from "@/lib/api";
import { useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { Save, Loader2, Plus, Trash2, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { ImageField } from "@/components/ImageField";
import { IMAGE_SLOTS, IMAGE_DEFAULTS } from "@/lib/assets";
import { ABOUT_DEFAULTS, ABOUT_FIELDS } from "@/lib/aboutContent";

const F = "w-full rounded-[12px] px-3 py-2 bg-background border border-border focus:outline-none focus:border-gold text-sm";
const Label = ({ children }) => <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{children}</label>;

export default function SettingsAdmin({ user }) {
  const { reloadSettings } = useApp();
  const [s, setS] = useState(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { api.get("/settings").then(({ data }) => setS(data)); }, []);
  if (!s) return <div className="h-64 bg-card rounded-[20px] animate-pulse" />;
  const set = (k) => (e) => setS({ ...s, [k]: e.target.value });

  const save = async () => {
    setBusy(true);
    try { await api.put("/admin/settings", s); await reloadSettings(); toast.success("Settings saved"); }
    catch (e) { toast.error(formatApiError(e.response?.data?.detail)); } finally { setBusy(false); }
  };

  const updStat = (i, k, v) => { const hs = [...(s.hero_stats || [])]; hs[i] = { ...hs[i], [k]: v }; setS({ ...s, hero_stats: hs }); };
  const updReach = (i, k, v) => { const rr = [...(s.advertise_reach || [])]; rr[i] = { ...rr[i], [k]: v }; setS({ ...s, advertise_reach: rr }); };
  const updSocial = (i, k, v) => { const sl = [...(s.social_links || [])]; sl[i] = { ...sl[i], [k]: v }; setS({ ...s, social_links: sl }); };
  const updRate = (i, k, v) => { const rc = [...(s.rate_card || [])]; rc[i] = { ...rc[i], [k]: v }; setS({ ...s, rate_card: rc }); };
  const updImg = (k, v) => setS({ ...s, site_images: { ...(s.site_images || {}), [k]: v } });

  return (
    <div className="max-w-3xl">
      <div className="flex items-center justify-between mb-6 sticky top-0 bg-background py-2 z-10">
        <h1 className="font-heading font-bold text-3xl">Settings</h1>
        <button onClick={save} disabled={busy} data-testid="settings-save" className="flex items-center gap-2 bg-gold text-midnight font-bold rounded-[14px] px-5 py-2.5 disabled:opacity-60">{busy ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />} Save</button>
      </div>

      <Section title="General">
        <div><Label>Site name</Label><input className={F} value={s.site_name || ""} onChange={set("site_name")} data-testid="set-sitename" /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Tagline (EN)</Label><input className={F} value={s.tagline_en || ""} onChange={set("tagline_en")} /></div>
          <div><Label>Tagline (TE)</Label><input className={F + " lang-te"} value={s.tagline_te || ""} onChange={set("tagline_te")} /></div>
        </div>
        <div><Label>Contact email</Label><input className={F} value={s.contact_email || ""} onChange={set("contact_email")} data-testid="set-contact" /></div>
      </Section>

      <Section title="Links">
        <div><Label>YouTube channel URL</Label><input className={F} value={s.youtube_channel_url || ""} onChange={set("youtube_channel_url")} data-testid="set-youtube" /></div>
        <div><Label>E-Paper URL (empty = "Coming soon")</Label><input className={F} value={s.epaper_url || ""} onChange={set("epaper_url")} data-testid="set-epaper" /></div>
        <div><Label>Media kit URL</Label><input className={F} value={s.media_kit_url || ""} onChange={set("media_kit_url")} data-testid="set-mediakit" /></div>
        <div>
          <Label>Social links</Label>
          {(s.social_links || []).map((sl, i) => (
            <div key={i} className="flex gap-2 mt-2">
              <input className={F} placeholder="Label" value={sl.label} onChange={(e) => updSocial(i, "label", e.target.value)} />
              <input className={F} placeholder="URL" value={sl.url} onChange={(e) => updSocial(i, "url", e.target.value)} />
              <button onClick={() => setS({ ...s, social_links: s.social_links.filter((_, x) => x !== i) })} className="p-2 text-destructive"><Trash2 size={16} /></button>
            </div>
          ))}
          <button onClick={() => setS({ ...s, social_links: [...(s.social_links || []), { label: "", url: "" }] })} className="mt-2 flex items-center gap-1 text-sm text-navy dark:text-gold font-semibold"><Plus size={14} /> Add social</button>
        </div>
      </Section>

      <Section title="About (shown on Home)">
        <div><Label>About (EN)</Label><textarea className={F + " min-h-[80px]"} value={s.about_en || ""} onChange={set("about_en")} /></div>
        <div><Label>About (TE)</Label><textarea className={F + " min-h-[80px] lang-te"} value={s.about_te || ""} onChange={set("about_te")} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Mission (EN)</Label><input className={F} value={s.mission_en || ""} onChange={set("mission_en")} /></div>
          <div><Label>Mission (TE)</Label><input className={F + " lang-te"} value={s.mission_te || ""} onChange={set("mission_te")} /></div>
        </div>
      </Section>

      <Section title="Hero stats (Home)">
        <p className="text-xs text-muted-foreground -mt-1">Edit the value and the category label (EN/TE). Add or remove stats freely.</p>
        {(s.hero_stats || []).map((st, i) => (
          <div key={i} className="flex gap-2 items-start" data-testid={`hero-stat-row-${i}`}>
            <div className="grid grid-cols-3 gap-2 flex-1">
              <input className={F} placeholder="Value (e.g. 100K+)" value={st.value} onChange={(e) => updStat(i, "value", e.target.value)} />
              <input className={F} placeholder="Category EN" value={st.label_en} onChange={(e) => updStat(i, "label_en", e.target.value)} />
              <input className={F + " lang-te"} placeholder="Category TE" value={st.label_te} onChange={(e) => updStat(i, "label_te", e.target.value)} />
            </div>
            <button onClick={() => setS({ ...s, hero_stats: s.hero_stats.filter((_, x) => x !== i) })} className="p-2 text-destructive mt-0.5" data-testid={`hero-stat-del-${i}`}><Trash2 size={16} /></button>
          </div>
        ))}
        <button onClick={() => setS({ ...s, hero_stats: [...(s.hero_stats || []), { value: "", label_en: "", label_te: "" }] })} data-testid="hero-stat-add" className="flex items-center gap-1 text-sm text-navy dark:text-gold font-semibold"><Plus size={14} /> Add stat</button>
      </Section>

      <Section title="Advertise page">
        <div><Label>Audience (EN)</Label><textarea className={F + " min-h-[70px]"} value={s.advertise_audience_en || ""} onChange={set("advertise_audience_en")} /></div>
        <div><Label>Audience (TE)</Label><textarea className={F + " min-h-[70px] lang-te"} value={s.advertise_audience_te || ""} onChange={set("advertise_audience_te")} /></div>
        <div>
          <Label>Reach stats (value + category)</Label>
          {(s.advertise_reach || []).map((r, i) => (
            <div key={i} className="flex gap-2 items-start mt-2" data-testid={`reach-stat-row-${i}`}>
              <div className="grid grid-cols-3 gap-2 flex-1">
                <input className={F} placeholder="Value (e.g. 5M+)" value={r.value} onChange={(e) => updReach(i, "value", e.target.value)} />
                <input className={F} placeholder="Category EN" value={r.label_en ?? r.label ?? ""} onChange={(e) => updReach(i, "label_en", e.target.value)} />
                <input className={F + " lang-te"} placeholder="Category TE" value={r.label_te || ""} onChange={(e) => updReach(i, "label_te", e.target.value)} />
              </div>
              <button onClick={() => setS({ ...s, advertise_reach: s.advertise_reach.filter((_, x) => x !== i) })} className="p-2 text-destructive mt-0.5" data-testid={`reach-stat-del-${i}`}><Trash2 size={16} /></button>
            </div>
          ))}
          <button onClick={() => setS({ ...s, advertise_reach: [...(s.advertise_reach || []), { value: "", label_en: "", label_te: "" }] })} data-testid="reach-stat-add" className="mt-2 flex items-center gap-1 text-sm text-navy dark:text-gold font-semibold"><Plus size={14} /> Add reach stat</button>
        </div>
        <div>
          <Label>Rate card</Label>
          {(s.rate_card || []).map((r, i) => (
            <div key={i} className="flex gap-2 mt-2">
              <input className={F} placeholder="Format" value={r.format} onChange={(e) => updRate(i, "format", e.target.value)} />
              <input className={F} placeholder="Price" value={r.price} onChange={(e) => updRate(i, "price", e.target.value)} />
              <button onClick={() => setS({ ...s, rate_card: s.rate_card.filter((_, x) => x !== i) })} className="p-2 text-destructive"><Trash2 size={16} /></button>
            </div>
          ))}
          <button onClick={() => setS({ ...s, rate_card: [...(s.rate_card || []), { format: "", price: "" }] })} className="mt-2 flex items-center gap-1 text-sm text-navy dark:text-gold font-semibold"><Plus size={14} /> Add rate</button>
        </div>
      </Section>

      <Section title="About page content">
        <p className="text-xs text-muted-foreground -mt-1">Edit the three sections of the <b>/about</b> page in English and Telugu. Leave a field blank to use the built‑in copy.</p>
        {ABOUT_FIELDS.map((fld) => (
          <div key={fld.base} className="grid md:grid-cols-2 gap-3" data-testid={`about-field-${fld.base}`}>
            <div>
              <Label>{fld.label} (EN)</Label>
              {fld.multiline
                ? <textarea className={F + " min-h-[120px]"} value={s[`${fld.base}_en`] ?? ABOUT_DEFAULTS.en[fld.base]} onChange={set(`${fld.base}_en`)} />
                : <input className={F} value={s[`${fld.base}_en`] ?? ABOUT_DEFAULTS.en[fld.base]} onChange={set(`${fld.base}_en`)} />}
            </div>
            <div>
              <Label>{fld.label} (TE)</Label>
              {fld.multiline
                ? <textarea className={F + " min-h-[120px] lang-te"} value={s[`${fld.base}_te`] ?? ABOUT_DEFAULTS.te[fld.base]} onChange={set(`${fld.base}_te`)} />
                : <input className={F + " lang-te"} value={s[`${fld.base}_te`] ?? ABOUT_DEFAULTS.te[fld.base]} onChange={set(`${fld.base}_te`)} />}
            </div>
          </div>
        ))}
      </Section>

      <Section title="Site images">
        <p className="text-xs text-muted-foreground -mt-1">Upload or paste a URL for any section image. Leave blank to use the built-in default. (Guest photos are managed inside the Guests editor.)</p>
        {IMAGE_SLOTS.map((sl) => (
          <ImageField key={sl.key} label={sl.label} value={(s.site_images || {})[sl.key]} defaultSrc={IMAGE_DEFAULTS[sl.key]} onChange={(v) => updImg(sl.key, v)} />
        ))}
      </Section>

      <Section title="Topics">
        <textarea className={F + " min-h-[60px]"} value={(s.topics || []).join(", ")} onChange={(e) => setS({ ...s, topics: e.target.value.split(",").map((t) => t.trim()).filter(Boolean) })} data-testid="set-topics" />
        <p className="text-xs text-muted-foreground">Comma-separated list.</p>
      </Section>

      <Section title="SEO defaults">
        <div><Label>SEO title</Label><input className={F} value={s.seo_title || ""} onChange={set("seo_title")} /></div>
        <div><Label>SEO description</Label><textarea className={F + " min-h-[60px]"} value={s.seo_description || ""} onChange={set("seo_description")} /></div>
      </Section>

      {user?.role === "owner" && <TeamSection />}
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="rounded-[20px] bg-card border border-border p-5 mb-5 space-y-3">
      <h2 className="font-heading font-bold text-lg">{title}</h2>
      {children}
    </div>
  );
}

function TeamSection() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "editor" });
  const load = () => api.get("/admin/users").then(({ data }) => setUsers(data));
  useEffect(() => { load(); }, []);
  const add = async () => {
    if (!form.email || !form.password) { toast.error("Email & password required"); return; }
    try { await api.post("/admin/users", form); toast.success("User added"); setForm({ name: "", email: "", password: "", role: "editor" }); load(); }
    catch (e) { toast.error(formatApiError(e.response?.data?.detail)); }
  };
  const del = async (id) => { await api.delete(`/admin/users/${id}`); load(); };
  return (
    <Section title="Team (Owner only)">
      {users.map((u) => (
        <div key={u.id} className="flex items-center justify-between text-sm border-b border-border pb-2">
          <span>{u.name || u.email} <span className="text-xs bg-navy/10 dark:bg-white/10 px-2 py-0.5 rounded-full ml-1">{u.role}</span></span>
          {u.role !== "owner" && <button onClick={() => del(u.id)} className="text-destructive"><Trash2 size={15} /></button>}
        </div>
      ))}
      <div className="grid grid-cols-2 gap-2 pt-2">
        <input className={F} placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input className={F} placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} data-testid="team-email" />
        <input className={F} type="password" placeholder="Password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} data-testid="team-password" />
        <select className={F} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}><option value="editor">Editor</option><option value="owner">Owner</option></select>
      </div>
      <button onClick={add} data-testid="team-add" className="flex items-center gap-1 bg-navy text-white rounded-[12px] px-4 py-2 text-sm font-semibold"><UserPlus size={16} /> Add team member</button>
    </Section>
  );
}
