import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Users, Mail, Inbox, Megaphone, Youtube, Newspaper, Megaphone as Ad } from "lucide-react";

const Stat = ({ icon: Icon, label, value, color }) => (
  <div className="rounded-[20px] bg-card border border-border p-5 shadow-sm flex items-center gap-4" data-testid={`stat-${label}`}>
    <div className="h-12 w-12 rounded-[14px] flex items-center justify-center" style={{ background: color + "22", color }}><Icon size={22} /></div>
    <div><div className="font-heading font-extrabold text-2xl">{value}</div><div className="text-xs text-muted-foreground">{label}</div></div>
  </div>
);

export default function Dashboard() {
  const [d, setD] = useState(null);
  useEffect(() => { api.get("/admin/dashboard").then(({ data }) => setD(data)).catch(() => {}); }, []);
  if (!d) return <div className="animate-pulse h-64 bg-card rounded-[20px]" />;

  return (
    <div>
      <h1 className="font-heading font-bold text-3xl mb-6">Dashboard</h1>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        <Stat icon={Users} label="Guests" value={d.totals.guests} color="#0F2F63" />
        <Stat icon={Mail} label="Subscribers" value={d.totals.subscribers} color="#3E9A9A" />
        <Stat icon={Inbox} label="Applications" value={d.totals.applications} color="#F4B73F" />
        <Stat icon={Megaphone} label="Ad Inquiries" value={d.totals.inquiries} color="#E03A2E" />
        <Stat icon={Users} label="Published" value={d.totals.published} color="#3A6FB5" />
      </div>

      <h2 className="font-heading font-bold text-xl mb-4">Clicks this week</h2>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Stat icon={Youtube} label="YouTube clicks" value={d.clicks_week.youtube} color="#E03A2E" />
        <Stat icon={Newspaper} label="E-Paper clicks" value={d.clicks_week.epaper} color="#0F2F63" />
        <Stat icon={Ad} label="Advertise clicks" value={d.clicks_week.advertise} color="#F4B73F" />
        <Stat icon={Mail} label="Newsletter signups" value={d.clicks_week.newsletter} color="#3E9A9A" />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-[20px] bg-card border border-border p-5">
          <h3 className="font-heading font-bold mb-3">Top 5 guests by clicks</h3>
          {d.top_guests.length === 0 ? <p className="text-sm text-muted-foreground">No clicks yet this week.</p> :
            <ul className="space-y-2">{d.top_guests.map((g, i) => <li key={i} className="flex justify-between text-sm border-b border-border pb-2"><span>{g.name}</span><span className="font-bold text-teal">{g.clicks}</span></li>)}</ul>}
        </div>
        <div className="rounded-[20px] bg-card border border-border p-5">
          <h3 className="font-heading font-bold mb-3">Latest applications</h3>
          {d.latest_applications.length === 0 ? <p className="text-sm text-muted-foreground">No applications yet.</p> :
            <ul className="space-y-2">{d.latest_applications.map((a, i) => <li key={i} className="flex justify-between text-sm border-b border-border pb-2"><span>{a.name} <span className="text-muted-foreground">· {a.expertise}</span></span><span className="text-xs bg-gold/20 text-navy dark:text-gold px-2 py-0.5 rounded-full">{a.status}</span></li>)}</ul>}
        </div>
      </div>
    </div>
  );
}
