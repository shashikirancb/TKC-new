import { useEffect, useState, useCallback } from "react";
import { api, formatApiError } from "@/lib/api";
import { Plus, Edit, Trash2, X, BarChart3, Download, Loader2, FileText, Copy } from "lucide-react";
import { toast } from "sonner";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { AD_SPECS, SLOT_ORDER, buildSpecSheet } from "@/lib/adSpecs";

const F = "w-full rounded-[12px] px-3 py-2 bg-background border border-border focus:outline-none focus:border-gold text-sm";
const SLOTS = ["home-top", "home-mid", "guests-grid", "guest-detail-sidebar", "footer-banner", "newsletter"];
const EMPTY = { advertiser: "", image_url: "", headline: "", destination_url: "", slots: [], start_date: "", end_date: "", status: "active", priority: 1, language: "all", embed_code: "", embed_enabled: false };

export default function AdsManager() {
  const [ads, setAds] = useState([]);
  const [editing, setEditing] = useState(null);
  const [report, setReport] = useState(null);
  const [showSpecs, setShowSpecs] = useState(false);
  const load = useCallback(async () => { const { data } = await api.get("/admin/ads"); setAds(data); }, []);
  useEffect(() => { load(); }, [load]);
  const del = async (id) => { if (!window.confirm("Delete campaign?")) return; await api.delete(`/admin/ads/${id}`); toast.success("Deleted"); load(); };

  const statusColor = (s) => s === "active" ? "bg-teal/20 text-teal" : s === "paused" ? "bg-gold/20 text-navy dark:text-gold" : "bg-muted text-muted-foreground";

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="font-heading font-bold text-3xl">Ads Manager</h1>
        <div className="flex gap-2">
          <button onClick={() => setShowSpecs(true)} data-testid="ad-specs-btn" className="flex items-center gap-2 border border-border font-semibold rounded-[14px] px-4 py-2.5 hover:bg-card transition-all"><FileText size={18} /> Ad specs</button>
          <button onClick={() => setEditing(EMPTY)} data-testid="add-ad-btn" className="flex items-center gap-2 bg-gold text-midnight font-bold rounded-[14px] px-5 py-2.5 hover:scale-[1.02] transition-all"><Plus size={18} /> New campaign</button>
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {ads.map((a) => (
          <div key={a.id} className="rounded-[20px] bg-card border border-border p-4" data-testid={`ad-${a.id}`}>
            <div className="flex gap-3">
              {a.image_url && <img src={a.image_url} alt="" className="h-16 w-24 object-cover rounded-[12px]" />}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2"><p className="font-semibold truncate">{a.advertiser}</p><span className={`text-xs px-2 py-0.5 rounded-full ${statusColor(a.status)}`}>{a.status}</span></div>
                <p className="text-sm text-muted-foreground truncate">{a.headline}</p>
                <div className="flex flex-wrap gap-1 mt-1">{a.slots?.map((s) => <span key={s} className="text-[10px] bg-navy/10 dark:bg-white/10 px-1.5 py-0.5 rounded-full">{s}</span>)}</div>
              </div>
            </div>
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-border text-xs text-muted-foreground">
              <span>Impr: <b className="text-foreground">{a.impressions || 0}</b></span>
              <span>Clicks: <b className="text-foreground">{a.clicks || 0}</b></span>
              <span>CTR: <b className="text-foreground">{a.ctr || 0}%</b></span>
              <div className="flex gap-1">
                <button onClick={() => api.get(`/admin/ads/${a.id}/report`).then(({ data }) => setReport(data))} data-testid={`ad-report-${a.id}`} className="p-1.5 rounded hover:bg-background"><BarChart3 size={15} /></button>
                <button onClick={() => setEditing(a)} data-testid={`edit-ad-${a.id}`} className="p-1.5 rounded hover:bg-background"><Edit size={15} /></button>
                <button onClick={() => del(a.id)} className="p-1.5 rounded hover:bg-destructive/20 text-destructive"><Trash2 size={15} /></button>
              </div>
            </div>
          </div>
        ))}
        {ads.length === 0 && <div className="text-center py-16 text-muted-foreground col-span-2">No campaigns.</div>}
      </div>
      {editing && <AdForm ad={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); load(); }} />}
      {report && <ReportModal report={report} onClose={() => setReport(null)} />}
      {showSpecs && <SpecModal onClose={() => setShowSpecs(false)} />}
    </div>
  );
}

function AdForm({ ad, onClose, onSaved }) {
  const [f, setF] = useState({ ...EMPTY, ...ad });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const toggleSlot = (s) => setF({ ...f, slots: f.slots.includes(s) ? f.slots.filter((x) => x !== s) : [...f.slots, s] });
  const save = async () => {
    if (!f.advertiser) { toast.error("Advertiser required"); return; }
    setBusy(true);
    try {
      const payload = { ...f, priority: Number(f.priority) };
      if (f.id) await api.put(`/admin/ads/${f.id}`, payload); else await api.post("/admin/ads", payload);
      toast.success("Saved"); onSaved();
    } catch (e) { toast.error(formatApiError(e.response?.data?.detail)); } finally { setBusy(false); }
  };
  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-start justify-center overflow-y-auto p-4" onClick={onClose}>
      <div className="bg-card rounded-[20px] w-full max-w-2xl my-8" onClick={(e) => e.stopPropagation()} data-testid="ad-form-modal">
        <div className="flex items-center justify-between p-5 border-b border-border"><h2 className="font-heading font-bold text-xl">{f.id ? "Edit" : "New"} campaign</h2><button onClick={onClose}><X size={20} /></button></div>
        <div className="p-5 space-y-3">
          <input className={F} placeholder="Advertiser name *" value={f.advertiser} onChange={set("advertiser")} data-testid="af-advertiser" />
          <input className={F} placeholder="Headline" value={f.headline} onChange={set("headline")} data-testid="af-headline" />
          <input className={F} placeholder="Creative image URL" value={f.image_url} onChange={set("image_url")} data-testid="af-image" />
          <input className={F} placeholder="Destination URL" value={f.destination_url} onChange={set("destination_url")} data-testid="af-dest" />
          <div>
            <p className="text-sm font-semibold mb-2">Slots</p>
            <div className="flex flex-wrap gap-2">{SLOTS.map((s) => <button key={s} type="button" onClick={() => toggleSlot(s)} data-testid={`af-slot-${s}`} className={`text-xs px-3 py-1.5 rounded-full border ${f.slots.includes(s) ? "bg-gold text-midnight border-gold" : "border-border"}`}>{s}</button>)}</div>
          </div>
          {f.slots.length > 0 && (
            <div className="rounded-[14px] bg-background border border-border p-3 space-y-2" data-testid="af-slot-specs">
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Creative size guidance</p>
              {f.slots.map((s) => AD_SPECS[s] && (
                <div key={s} className="text-xs flex flex-wrap gap-x-3 gap-y-0.5">
                  <span className="font-semibold text-foreground">{AD_SPECS[s].name}:</span>
                  <span className="text-muted-foreground">Desktop {AD_SPECS[s].desktop}</span>
                  <span className="text-muted-foreground">· Ratio {AD_SPECS[s].ratio}</span>
                  <span className="text-muted-foreground">· {AD_SPECS[s].format}, ≤ {AD_SPECS[s].max}</span>
                </div>
              ))}
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs text-muted-foreground">Start</label><input type="date" className={F} value={f.start_date} onChange={set("start_date")} data-testid="af-start" /></div>
            <div><label className="text-xs text-muted-foreground">End</label><input type="date" className={F} value={f.end_date} onChange={set("end_date")} data-testid="af-end" /></div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <select className={F} value={f.status} onChange={set("status")} data-testid="af-status"><option value="active">Active</option><option value="paused">Paused</option><option value="ended">Ended</option></select>
            <input className={F} type="number" placeholder="Priority" value={f.priority} onChange={set("priority")} data-testid="af-priority" />
            <select className={F} value={f.language} onChange={set("language")}><option value="all">All langs</option><option value="en">English</option><option value="te">Telugu</option></select>
          </div>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.embed_enabled} onChange={set("embed_enabled")} className="accent-[#F4B73F]" /> Use script/embed ad (e.g. AdSense)</label>
          {f.embed_enabled && <textarea className={F + " min-h-[70px] font-mono text-xs"} placeholder="<script>…</script>" value={f.embed_code} onChange={set("embed_code")} />}
        </div>
        <div className="flex justify-end gap-3 p-5 border-t border-border">
          <button onClick={onClose} className="rounded-[14px] px-5 py-2.5 font-semibold border border-border">Cancel</button>
          <button onClick={save} disabled={busy} data-testid="af-save" className="flex items-center gap-2 bg-gold text-midnight font-bold rounded-[14px] px-5 py-2.5 disabled:opacity-60">{busy && <Loader2 size={16} className="animate-spin" />} Save</button>
        </div>
      </div>
    </div>
  );
}

function ReportModal({ report, onClose }) {
  const { ad, daily } = report;
  const exportCSV = () => {
    const text = ["date,impressions,clicks", ...daily.map((d) => `${d.date},${d.impressions || 0},${d.clicks || 0}`)].join("\n");
    const blob = new Blob([text], { type: "text/csv" }); const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = `${ad.advertiser}-report.csv`; a.click();
  };
  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card rounded-[20px] w-full max-w-2xl p-6" onClick={(e) => e.stopPropagation()} data-testid="ad-report-modal">
        <div className="flex items-center justify-between mb-4"><h2 className="font-heading font-bold text-xl">{ad.advertiser} — Report</h2><button onClick={onClose}><X size={20} /></button></div>
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="rounded-[14px] bg-background p-3 text-center"><div className="font-bold text-2xl">{ad.impressions || 0}</div><div className="text-xs text-muted-foreground">Impressions</div></div>
          <div className="rounded-[14px] bg-background p-3 text-center"><div className="font-bold text-2xl">{ad.clicks || 0}</div><div className="text-xs text-muted-foreground">Clicks</div></div>
          <div className="rounded-[14px] bg-background p-3 text-center"><div className="font-bold text-2xl">{ad.impressions ? ((ad.clicks / ad.impressions) * 100).toFixed(1) : 0}%</div><div className="text-xs text-muted-foreground">CTR</div></div>
        </div>
        <div className="h-56">
          {daily.length ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={daily}><CartesianGrid strokeDasharray="3 3" opacity={0.2} /><XAxis dataKey="date" fontSize={11} /><YAxis fontSize={11} /><Tooltip /><Line type="monotone" dataKey="impressions" stroke="#3A6FB5" /><Line type="monotone" dataKey="clicks" stroke="#F4B73F" /></LineChart>
            </ResponsiveContainer>
          ) : <div className="h-full flex items-center justify-center text-muted-foreground text-sm">No data yet.</div>}
        </div>
        <button onClick={exportCSV} className="mt-4 flex items-center gap-2 bg-navy text-white rounded-[14px] px-4 py-2 text-sm font-semibold"><Download size={16} /> Export report (CSV)</button>
      </div>
    </div>
  );
}

function SpecModal({ onClose }) {
  const sheet = buildSpecSheet();
  const copy = () => { navigator.clipboard.writeText(sheet); toast.success("Spec sheet copied — paste it into an email"); };
  const download = () => {
    const blob = new Blob([sheet], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "kalyan-chronicles-ad-specs.txt"; a.click();
  };
  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-start justify-center overflow-y-auto p-4" onClick={onClose}>
      <div className="bg-card rounded-[20px] w-full max-w-2xl my-8" onClick={(e) => e.stopPropagation()} data-testid="ad-specs-modal">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="font-heading font-bold text-xl">Advertising creative specs</h2>
          <button onClick={onClose}><X size={20} /></button>
        </div>
        <div className="p-5 space-y-3">
          <p className="text-sm text-muted-foreground">Share these dimensions with advertisers. Each creative is shown at a fixed aspect ratio and scaled responsively for desktop and mobile automatically.</p>
          <div className="grid gap-3 sm:grid-cols-2">
            {SLOT_ORDER.map((k) => {
              const s = AD_SPECS[k];
              return (
                <div key={k} className="rounded-[14px] border border-border p-3" data-testid={`spec-${k}`}>
                  <p className="font-semibold text-sm">{s.name}</p>
                  <p className="text-[11px] text-muted-foreground mb-2">slot id: {k}</p>
                  <dl className="text-xs space-y-0.5">
                    <div className="flex justify-between"><dt className="text-muted-foreground">Desktop</dt><dd className="font-medium">{s.desktop}</dd></div>
                    <div className="flex justify-between"><dt className="text-muted-foreground">Mobile</dt><dd className="font-medium">{s.mobile}</dd></div>
                    <div className="flex justify-between"><dt className="text-muted-foreground">Ratio</dt><dd className="font-medium">{s.ratio}</dd></div>
                    <div className="flex justify-between"><dt className="text-muted-foreground">Format</dt><dd className="font-medium">{s.format}</dd></div>
                    <div className="flex justify-between"><dt className="text-muted-foreground">Max size</dt><dd className="font-medium">{s.max}</dd></div>
                  </dl>
                  <p className="text-[11px] text-muted-foreground mt-2">{s.notes}</p>
                </div>
              );
            })}
          </div>
        </div>
        <div className="flex justify-end gap-3 p-5 border-t border-border">
          <button onClick={copy} data-testid="spec-copy" className="flex items-center gap-2 border border-border rounded-[14px] px-4 py-2.5 text-sm font-semibold"><Copy size={16} /> Copy for email</button>
          <button onClick={download} data-testid="spec-download" className="flex items-center gap-2 bg-gold text-midnight font-bold rounded-[14px] px-4 py-2.5 text-sm"><Download size={16} /> Download .txt</button>
        </div>
      </div>
    </div>
  );
}
