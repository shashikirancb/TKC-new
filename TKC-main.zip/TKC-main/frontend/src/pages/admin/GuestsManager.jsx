import { useEffect, useState, useCallback } from "react";
import { api, formatApiError } from "@/lib/api";
import { useApp } from "@/context/AppContext";
import { Plus, Search, Edit, Copy, Trash2, Star, Pin, X, Loader2, Languages, Youtube, CheckCircle2, GripVertical } from "lucide-react";
import { toast } from "sonner";
import { PhotoUpload } from "@/components/PhotoUpload";

const F = "w-full rounded-[12px] px-3 py-2 bg-background border border-border focus:outline-none focus:border-gold text-sm";
const YT_RE = /(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/;
const vid = (u) => { const m = (u || "").match(YT_RE) || (u || "").match(/[?&]v=([A-Za-z0-9_-]{11})/); return m ? m[1] : null; };

const EMPTY = { name: "", designation: "", topic: "", photo_url: "", youtube_url: "", title_en: "", title_te: "", synopsis_en: "", synopsis_te: "", bio: "", episode_date: "", tags: [], featured: false, pinned: false, status: "draft", te_reviewed: false };

export default function GuestsManager() {
  const { settings } = useApp();
  const [guests, setGuests] = useState([]);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [editing, setEditing] = useState(null);
  const [selected, setSelected] = useState([]);

  const load = useCallback(async () => {
    const { data } = await api.get("/admin/guests", { params: { q, status } });
    setGuests(data);
  }, [q, status]);
  useEffect(() => { const d = setTimeout(load, 200); return () => clearTimeout(d); }, [load]);

  const del = async (id) => { if (!window.confirm("Delete this guest?")) return; await api.delete(`/admin/guests/${id}`); toast.success("Deleted"); load(); };
  const dup = async (id) => { await api.post(`/admin/guests/${id}/duplicate`); toast.success("Duplicated"); load(); };
  const toggleFeat = async (g) => { await api.put(`/admin/guests/${g.id}`, { ...g, featured: !g.featured }); load(); };
  const bulk = async (action) => { if (!selected.length) return; if (action === "delete" && !window.confirm("Delete selected?")) return; await api.post("/admin/guests/bulk", { ids: selected, action }); setSelected([]); toast.success("Done"); load(); };

  const featured = guests.filter((g) => g.featured);
  const saveOrder = async (ordered) => {
    setGuests((prev) => { const map = new Map(ordered.map((g, i) => [g.id, i])); return [...prev].sort((a, b) => (map.has(a.id) ? map.get(a.id) : 999) - (map.has(b.id) ? map.get(b.id) : 999)); });
    await api.post("/admin/guests/reorder", { ids: ordered.map((g) => g.id) });
    toast.success("Carousel order saved");
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="font-heading font-bold text-3xl">Guests</h1>
        <button onClick={() => setEditing(EMPTY)} data-testid="add-guest-btn" className="flex items-center gap-2 bg-gold text-midnight font-bold rounded-[14px] px-5 py-2.5 hover:scale-[1.02] transition-all"><Plus size={18} /> Add guest</button>
      </div>

      <div className="flex gap-3 mb-4 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search guests…" data-testid="admin-guest-search" className={F + " pl-9"} />
        </div>
        <select value={status} onChange={(e) => setStatus(e.target.value)} className={F + " w-auto"} data-testid="admin-guest-status-filter">
          <option value="all">All status</option><option value="published">Published</option><option value="draft">Draft</option>
        </select>
      </div>

      {selected.length > 0 && (
        <div className="flex gap-2 mb-3 items-center text-sm bg-card border border-border rounded-[14px] p-2">
          <span className="px-2">{selected.length} selected</span>
          <button onClick={() => bulk("publish")} className="px-3 py-1 rounded-full bg-teal text-white text-xs">Publish</button>
          <button onClick={() => bulk("unpublish")} className="px-3 py-1 rounded-full bg-navy text-white text-xs">Unpublish</button>
          <button onClick={() => bulk("delete")} className="px-3 py-1 rounded-full bg-destructive text-white text-xs">Delete</button>
        </div>
      )}

      {featured.length > 1 && <FeaturedReorder featured={featured} onReorder={saveOrder} />}

      <div className="rounded-[20px] bg-card border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-background text-left"><tr>
              <th className="p-3 w-8"></th><th className="p-3">Guest</th><th className="p-3 hidden sm:table-cell">Topic</th><th className="p-3">Status</th><th className="p-3">Featured</th><th className="p-3 text-right">Actions</th>
            </tr></thead>
            <tbody>
              {guests.map((g) => (
                <tr key={g.id} className="border-t border-border hover:bg-background/50" data-testid={`guest-row-${g.id}`}>
                  <td className="p-3"><input type="checkbox" checked={selected.includes(g.id)} onChange={(e) => setSelected(e.target.checked ? [...selected, g.id] : selected.filter((x) => x !== g.id))} className="accent-[#F4B73F]" /></td>
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      {g.thumbnail && <img src={g.thumbnail} alt="" className="h-9 w-14 object-cover rounded" />}
                      <div><div className="font-semibold flex items-center gap-1">{g.name}{g.pinned && <Pin size={12} className="text-gold" />}</div><div className="text-xs text-muted-foreground line-clamp-1">{g.title_en}</div></div>
                    </div>
                  </td>
                  <td className="p-3 hidden sm:table-cell"><span className="text-xs bg-teal/15 text-teal px-2 py-0.5 rounded-full">{g.topic}</span></td>
                  <td className="p-3"><span className={`text-xs px-2 py-0.5 rounded-full ${g.status === "published" ? "bg-teal/20 text-teal" : "bg-muted text-muted-foreground"}`}>{g.status}</span></td>
                  <td className="p-3"><button onClick={() => toggleFeat(g)} data-testid={`feature-toggle-${g.id}`}><Star size={18} className={g.featured ? "text-gold fill-gold" : "text-muted-foreground"} /></button></td>
                  <td className="p-3"><div className="flex gap-1 justify-end">
                    <button onClick={() => setEditing(g)} data-testid={`edit-guest-${g.id}`} className="p-1.5 rounded hover:bg-background"><Edit size={15} /></button>
                    <button onClick={() => dup(g.id)} className="p-1.5 rounded hover:bg-background"><Copy size={15} /></button>
                    <button onClick={() => del(g.id)} data-testid={`delete-guest-${g.id}`} className="p-1.5 rounded hover:bg-destructive/20 text-destructive"><Trash2 size={15} /></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {guests.length === 0 && <div className="p-10 text-center text-muted-foreground">No guests found.</div>}
      </div>

      {editing && <GuestForm guest={editing} topics={settings?.topics || []} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); load(); }} />}
    </div>
  );
}

function FeaturedReorder({ featured, onReorder }) {
  const [items, setItems] = useState(featured);
  const [dragIdx, setDragIdx] = useState(null);
  useEffect(() => { setItems(featured); }, [featured.map((g) => g.id).join(",")]);

  const onDrop = (idx) => {
    if (dragIdx === null || dragIdx === idx) return;
    const next = [...items];
    const [moved] = next.splice(dragIdx, 1);
    next.splice(idx, 0, moved);
    setItems(next);
    setDragIdx(null);
    onReorder(next);
  };

  return (
    <div className="rounded-[20px] bg-card border border-border p-4 mb-4" data-testid="featured-reorder">
      <h3 className="font-heading font-bold text-sm mb-1">Home carousel order</h3>
      <p className="text-xs text-muted-foreground mb-3">Drag featured guests to set the order they appear in the Home carousel.</p>
      <div className="flex flex-wrap gap-2">
        {items.map((g, i) => (
          <div key={g.id} draggable onDragStart={() => setDragIdx(i)} onDragOver={(e) => e.preventDefault()} onDrop={() => onDrop(i)}
            data-testid={`reorder-item-${g.id}`}
            className={`flex items-center gap-2 bg-background border rounded-[14px] pl-2 pr-3 py-1.5 cursor-grab active:cursor-grabbing transition-all ${dragIdx === i ? "opacity-40 border-gold" : "border-border"}`}>
            <GripVertical size={14} className="text-muted-foreground" />
            <span className="text-xs font-bold text-gold">{i + 1}</span>
            {g.thumbnail && <img src={g.thumbnail} alt="" className="h-7 w-11 object-cover rounded" />}
            <span className="text-sm font-semibold">{g.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function GuestForm({ guest, topics, onClose, onSaved }) {
  const [f, setF] = useState({ ...EMPTY, ...guest });
  const [busy, setBusy] = useState(false);
  const [translating, setTranslating] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const videoId = vid(f.youtube_url);
  const ytValid = !f.youtube_url || !!videoId;

  const translate = async () => {
    if (!f.synopsis_en) { toast.error("Enter English synopsis first"); return; }
    setTranslating(true);
    try {
      const { data } = await api.post("/admin/translate", { title_en: f.title_en, synopsis_en: f.synopsis_en });
      setF((p) => ({ ...p, title_te: data.title_te || p.title_te, synopsis_te: data.synopsis_te || p.synopsis_te, te_reviewed: false }));
      toast.success("Translated — please review");
    } catch (e) { toast.error("Translation failed"); } finally { setTranslating(false); }
  };

  const save = async (publish) => {
    if (!f.name) { toast.error("Name required"); return; }
    if (!ytValid) { toast.error("Invalid YouTube link"); return; }
    const payload = { ...f, status: publish ? "published" : "draft", tags: f.topic ? [f.topic] : f.tags };
    if (publish && f.synopsis_te && !f.te_reviewed) { toast.error("Tick 'Reviewed' before publishing the Telugu version"); return; }
    setBusy(true);
    try {
      if (f.id) await api.put(`/admin/guests/${f.id}`, payload);
      else await api.post("/admin/guests", payload);
      toast.success(publish ? "Published" : "Saved as draft");
      onSaved();
    } catch (e) { toast.error(formatApiError(e.response?.data?.detail)); } finally { setBusy(false); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-start justify-center overflow-y-auto p-4" onClick={onClose}>
      <div className="bg-card rounded-[20px] w-full max-w-4xl my-8 shadow-2xl" onClick={(e) => e.stopPropagation()} data-testid="guest-form-modal">
        <div className="flex items-center justify-between p-5 border-b border-border sticky top-0 bg-card rounded-t-[20px] z-10">
          <h2 className="font-heading font-bold text-xl">{f.id ? "Edit guest" : "Add guest"}</h2>
          <button onClick={onClose} className="p-1.5 rounded hover:bg-background"><X size={20} /></button>
        </div>
        <div className="p-5 grid lg:grid-cols-2 gap-5">
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <input className={F} placeholder="Guest name *" value={f.name} onChange={set("name")} data-testid="gf-name" />
              <input className={F} placeholder="Designation / org" value={f.designation} onChange={set("designation")} data-testid="gf-designation" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <input className={F} list="topics-list" placeholder="Topic" value={f.topic} onChange={set("topic")} data-testid="gf-topic" />
              <datalist id="topics-list">{topics.map((t) => <option key={t} value={t} />)}</datalist>
              <input className={F} type="date" value={f.episode_date} onChange={set("episode_date")} data-testid="gf-date" />
            </div>
            <PhotoUpload value={f.photo_url} onChange={(url) => setF((p) => ({ ...p, photo_url: url }))} />
            <div>
              <input className={F + (ytValid ? "" : " border-destructive")} placeholder="YouTube link (watch / youtu.be / shorts)" value={f.youtube_url} onChange={set("youtube_url")} data-testid="gf-youtube" />
              {!ytValid && <p className="text-xs text-destructive mt-1">Invalid YouTube link</p>}
            </div>
            <input className={F} placeholder="Episode title (English)" value={f.title_en} onChange={set("title_en")} data-testid="gf-title-en" />
            <textarea className={F + " min-h-[100px]"} maxLength={1500} placeholder="Synopsis (English, max 1500)" value={f.synopsis_en} onChange={set("synopsis_en")} data-testid="gf-synopsis-en" />
            <button type="button" onClick={translate} disabled={translating} data-testid="gf-translate-btn" className="flex items-center gap-2 bg-teal text-white font-semibold rounded-[12px] px-4 py-2 text-sm disabled:opacity-60">
              {translating ? <Loader2 size={16} className="animate-spin" /> : <Languages size={16} />} Translate to Telugu
            </button>
            <input className={F + " lang-te"} placeholder="శీర్షిక (Telugu title)" value={f.title_te} onChange={set("title_te")} data-testid="gf-title-te" />
            <textarea className={F + " min-h-[100px] lang-te"} placeholder="సారాంశం (Telugu synopsis)" value={f.synopsis_te} onChange={set("synopsis_te")} data-testid="gf-synopsis-te" />
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.te_reviewed} onChange={set("te_reviewed")} className="accent-[#F4B73F]" data-testid="gf-reviewed" /> Telugu Reviewed</label>
            <textarea className={F + " min-h-[60px]"} placeholder="Guest bio" value={f.bio} onChange={set("bio")} data-testid="gf-bio" />
            <div className="flex gap-4">
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.featured} onChange={set("featured")} className="accent-[#F4B73F]" data-testid="gf-featured" /> Featured</label>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.pinned} onChange={set("pinned")} className="accent-[#F4B73F]" data-testid="gf-pinned" /> Pin as hero</label>
            </div>
          </div>

          {/* preview */}
          <div className="space-y-4">
            <p className="text-xs uppercase tracking-wider font-bold text-muted-foreground">Live preview</p>
            <div className="rounded-[20px] bg-background border border-border overflow-hidden">
              <div className="relative aspect-video bg-midnight">
                {(f.photo_url || videoId) && <img src={f.photo_url || `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`} alt="" className="w-full h-full object-cover" />}
                <div className="absolute inset-0 flex items-center justify-center"><div className="h-12 w-12 rounded-full bg-gold flex items-center justify-center"><Youtube size={22} className="text-midnight" /></div></div>
              </div>
              <div className="p-4">
                <h3 className="font-heading font-bold">{f.title_en || "Episode title"}</h3>
                {f.title_te && <h3 className="font-heading font-bold lang-te text-sm text-teal mt-1">{f.title_te}</h3>}
                <p className="text-sm font-semibold text-teal mt-1">{f.name || "Guest name"}</p>
                <p className="text-xs text-muted-foreground">{f.designation}</p>
                <p className="text-sm text-muted-foreground mt-2 line-clamp-3">{f.synopsis_en}</p>
              </div>
            </div>
            {f.synopsis_te && (
              <div className="rounded-[14px] bg-background border border-border p-3 lang-te">
                <p className="text-xs uppercase tracking-wider font-bold text-muted-foreground mb-1 font-sans">Telugu preview</p>
                <p className="text-sm">{f.synopsis_te}</p>
                {f.te_reviewed && <span className="inline-flex items-center gap-1 text-xs text-teal mt-2 font-sans"><CheckCircle2 size={13} /> Reviewed</span>}
              </div>
            )}
          </div>
        </div>
        <div className="flex justify-end gap-3 p-5 border-t border-border sticky bottom-0 bg-card rounded-b-[20px]">
          <button onClick={() => save(false)} disabled={busy} data-testid="gf-save-draft" className="rounded-[14px] px-5 py-2.5 font-semibold border border-border hover:bg-background">Save as Draft</button>
          <button onClick={() => save(true)} disabled={busy} data-testid="gf-publish" className="flex items-center gap-2 bg-gold text-midnight font-bold rounded-[14px] px-5 py-2.5 hover:scale-[1.02] transition-all disabled:opacity-60">{busy && <Loader2 size={16} className="animate-spin" />} Publish</button>
        </div>
      </div>
    </div>
  );
}
