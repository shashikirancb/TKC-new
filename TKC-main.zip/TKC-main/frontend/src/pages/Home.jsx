import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Play, Youtube, Newspaper, ArrowRight, ChevronLeft, ChevronRight, CheckCircle2 } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { api, openExternal } from "@/lib/api";
import { PublicLayout } from "@/components/PublicLayout";
import { AdSlot } from "@/components/AdSlot";
import { GuestCard } from "@/components/GuestCard";
import { RegisterGuestForm } from "@/components/RegisterGuestForm";
import { NewsletterForm } from "@/components/NewsletterForm";
import { STUDIO_IMG, STUDIO_IMG_2, siteImg } from "@/lib/assets";import { toast } from "sonner";

export default function Home() {
  const { tr, lang, pick, settings } = useApp();
  const [latest, setLatest] = useState(null);
  const [featured, setFeatured] = useState([]);

  useEffect(() => {
    api.get("/guests/latest").then(({ data }) => setLatest(data)).catch(() => {});
    api.get("/guests/featured").then(({ data }) => setFeatured(data)).catch(() => {});
  }, []);

  const epaper = settings?.epaper_url;
  const yt = settings?.youtube_channel_url;
  const openEpaper = () => epaper ? openExternal(epaper, "click_epaper") : toast.info(tr("coming_soon"));

  const lTitle = latest ? ((lang === "te" && latest.title_te) ? latest.title_te : latest.title_en) : "";
  const lSyn = latest ? ((lang === "te" && latest.synopsis_te) ? latest.synopsis_te : latest.synopsis_en) : "";

  return (
    <PublicLayout>
      {/* HERO */}
      <section className="bg-midnight text-cream relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-gold/10 blur-3xl" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-14 sm:py-20 grid lg:grid-cols-2 gap-10 items-center relative">
          <div className="anim-float">
            <span className="inline-block bg-alert text-white text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-4">{tr("latest_episode")}</span>
            <h1 className="font-heading font-extrabold text-4xl sm:text-5xl lg:text-6xl leading-tight">{lTitle || "The Kalyan Chronicles"}</h1>
            {latest && <p className="mt-4 text-teal font-semibold text-lg">{latest.name} <span className="text-cream/60 font-normal">· {latest.designation}</span></p>}
            <p className="mt-3 text-cream/75 leading-relaxed max-w-xl line-clamp-3">{lSyn || tr("footer_about")}</p>
            <div className="flex flex-wrap gap-3 mt-7">
              <button onClick={() => openExternal(latest?.youtube_url || yt, "click_youtube", { video_id: latest?.video_id, source: "hero" })}
                data-testid="hero-watch-youtube-btn"
                className="flex items-center gap-2 bg-gold hover:bg-[#E5A72E] text-midnight font-bold rounded-[14px] px-6 py-3 transition-all hover:scale-[1.02] shadow-[0_4px_24px_rgba(244,183,63,0.35)]">
                <Youtube size={20} /> {tr("watch_youtube")}
              </button>
              <button onClick={openEpaper} data-testid="hero-epaper-btn"
                className="flex items-center gap-2 border-2 border-gold text-gold hover:bg-gold hover:text-midnight font-semibold rounded-[14px] px-5 py-3 transition-all">
                <Newspaper size={18} /> {tr("read_epaper")}
              </button>
            </div>
          </div>
          <div className="anim-float" style={{ animationDelay: "120ms" }}>
            <button onClick={() => openExternal(latest?.youtube_url || yt, "click_youtube", { video_id: latest?.video_id, source: "hero-thumb" })}
              data-testid="hero-thumbnail" className="relative w-full aspect-video rounded-[20px] overflow-hidden shadow-2xl group block">
              <img src={latest?.thumbnail || latest?.yt_thumbnail || STUDIO_IMG} alt={lTitle} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-midnight/20 flex items-center justify-center">
                <div className="relative">
                  <span className="absolute inset-0 rounded-full bg-gold/40" style={{ animation: "pulse-ring 2s infinite" }} />
                  <div className="relative h-16 w-16 rounded-full bg-gold flex items-center justify-center"><Play size={28} className="text-midnight ml-1" fill="currentColor" /></div>
                </div>
              </div>
            </button>
          </div>
        </div>
        {/* trust strip */}
        <div className="border-t border-white/10 bg-ink/40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5 flex flex-wrap gap-6 sm:gap-12 justify-center sm:justify-start items-center">
            {(settings?.hero_stats || []).map((s, i) => (
              <div key={i} className="text-center sm:text-left" data-testid={`hero-stat-${i}`}>
                <div className="font-heading font-extrabold text-2xl text-gold">{s.value}</div>
                <div className="text-xs text-cream/60 uppercase tracking-wider">{lang === "te" ? s.label_te : s.label_en}</div>
              </div>
            ))}
            <span className="text-xs text-cream/50 ml-auto hidden md:block">{tr("trust_strip")}</span>
          </div>
        </div>
      </section>

      {/* AD home-top */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 mt-8">
        <AdSlot slot="home-top" className="h-24 sm:h-28" />
      </div>

      {/* ABOUT */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16 grid lg:grid-cols-2 gap-10 items-center">
        <div className="relative">
          <img src={siteImg(settings, "home_about")} alt="The Kalyan Chronicles studio" loading="lazy" className="rounded-[20px] w-full object-cover shadow-[0_20px_40px_rgba(15,47,99,0.15)]" />
          <div className="absolute -bottom-5 -right-3 bg-gold text-midnight font-heading font-bold rounded-[16px] px-5 py-3 shadow-lg hidden sm:block">Inspire &amp; Inform</div>
        </div>
        <div>
          <span className="uppercase text-xs tracking-[0.2em] font-bold text-gold">{tr("about_host")}</span>
          <h2 className="font-heading font-bold text-2xl sm:text-3xl lg:text-4xl mt-2">{settings?.site_name}</h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">{pick(settings, "about")}</p>
          <p className="mt-3 font-semibold text-teal">{pick(settings, "mission")}</p>
          <ul className="mt-5 space-y-2">
            {((lang === "te" ? settings?.values_te : settings?.values_en) || []).map((v, i) => (
              <li key={i} className="flex items-center gap-2 text-sm"><CheckCircle2 size={18} className="text-teal shrink-0" /> {v}</li>
            ))}
          </ul>
          <button onClick={() => openExternal(yt, "click_youtube", { source: "about" })} data-testid="about-subscribe-btn"
            className="mt-6 flex items-center gap-2 bg-navy hover:bg-midnight text-white font-semibold rounded-[14px] px-5 py-3 transition-all hover:scale-[1.02]">
            <Youtube size={18} /> {tr("watch_youtube")}
          </button>
        </div>
      </section>

      {/* HIGHLIGHT GUESTS CAROUSEL */}
      <section className="bg-card/50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="uppercase text-xs tracking-[0.2em] font-bold text-gold">{tr("featured_conversations")}</span>
              <h2 className="font-heading font-bold text-2xl sm:text-3xl lg:text-4xl mt-1">{tr("highlight_guests")}</h2>
            </div>
            <Link to="/guests" data-testid="view-all-guests-btn" className="hidden sm:flex items-center gap-1.5 text-navy dark:text-gold font-semibold hover:gap-2.5 transition-all">
              {tr("view_all_guests")} <ArrowRight size={18} />
            </Link>
          </div>
          <Carousel items={featured} />
          <Link to="/guests" className="sm:hidden mt-6 flex items-center justify-center gap-2 border-2 border-gold text-gold font-semibold rounded-[14px] px-5 py-3">
            {tr("view_all_guests")} <ArrowRight size={18} />
          </Link>
        </div>
      </section>

      {/* E-PAPER PROMO BAND */}
      <section className="bg-midnight text-cream py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid md:grid-cols-2 gap-8 items-center">
          <div className="relative rounded-[20px] overflow-hidden aspect-[4/3] border border-white/10">
            <img src={siteImg(settings, "home_epaper")} alt="E-Paper" loading="lazy" className="w-full h-full object-cover opacity-80" />
            <span className="absolute top-3 left-3 bg-gold text-midnight text-xs font-bold px-3 py-1 rounded-full">E-PAPER</span>
          </div>
          <div>
            <h2 className="font-heading font-bold text-2xl sm:text-3xl lg:text-4xl">{tr("epaper_promo_title")}</h2>
            <p className="mt-3 text-cream/75 leading-relaxed">{tr("epaper_promo_text")}</p>
            <button onClick={openEpaper} data-testid="epaper-promo-btn"
              className="mt-6 inline-flex items-center gap-2 bg-gold hover:bg-[#E5A72E] text-midnight font-bold rounded-[14px] px-6 py-3 transition-all hover:scale-[1.02]">
              <Newspaper size={18} /> {tr("open_epaper")}
            </button>
          </div>
        </div>
      </section>

      {/* REGISTER TO BE A GUEST */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 py-16" id="apply">
        <div className="text-center mb-8">
          <span className="uppercase text-xs tracking-[0.2em] font-bold text-gold">{tr("nav_apply")}</span>
          <h2 className="font-heading font-bold text-2xl sm:text-3xl lg:text-4xl mt-1">{tr("register_title")}</h2>
          <p className="text-muted-foreground mt-2">{tr("register_sub")}</p>
        </div>
        <div className="bg-card border border-border rounded-[20px] p-6 sm:p-8 shadow-[0_12px_32px_rgba(15,47,99,0.08)]">
          <RegisterGuestForm />
        </div>
      </section>

      {/* AD home-mid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <AdSlot slot="home-mid" className="h-24 sm:h-28" />
      </div>

      {/* NEWSLETTER */}
      <section className="max-w-3xl mx-auto px-4 sm:px-6 py-16">
        <div className="bg-cream dark:bg-card border-2 border-gold/40 rounded-[20px] p-6 sm:p-10 text-center shadow-[0_12px_32px_rgba(15,47,99,0.08)]">
          <h2 className="font-heading font-bold text-2xl sm:text-3xl">{tr("newsletter_title")}</h2>
          <p className="text-muted-foreground mt-2 mb-6">{tr("newsletter_sub")}</p>
          <NewsletterForm />
        </div>
      </section>
    </PublicLayout>
  );
}

function Carousel({ items }) {
  const scroll = (dir) => {
    const el = document.getElementById("guest-carousel");
    if (el) el.scrollBy({ left: dir * (el.clientWidth * 0.8), behavior: "smooth" });
  };
  if (!items.length) return <div className="text-center text-muted-foreground py-10">No featured guests yet.</div>;
  return (
    <div className="relative">
      <div id="guest-carousel" className="flex gap-5 overflow-x-auto scrollbar-hide snap-x pb-2 -mx-1 px-1">
        {items.map((g, i) => (
          <div key={g.id} className="snap-start shrink-0 w-[280px] sm:w-[320px]"><GuestCard guest={g} index={i} /></div>
        ))}
      </div>
      {items.length > 2 && (
        <>
          <button onClick={() => scroll(-1)} data-testid="carousel-prev" className="hidden sm:flex absolute -left-4 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-card border border-border shadow-lg items-center justify-center hover:bg-gold hover:text-midnight transition-colors"><ChevronLeft size={20} /></button>
          <button onClick={() => scroll(1)} data-testid="carousel-next" className="hidden sm:flex absolute -right-4 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-card border border-border shadow-lg items-center justify-center hover:bg-gold hover:text-midnight transition-colors"><ChevronRight size={20} /></button>
        </>
      )}
    </div>
  );
}
