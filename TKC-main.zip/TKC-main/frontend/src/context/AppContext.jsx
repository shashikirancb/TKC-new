import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { api } from "@/lib/api";
import { t } from "@/lib/i18n";

const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);

export function AppProvider({ children }) {
  const [lang, setLang] = useState(() => localStorage.getItem("kc_lang") || "en");
  const [theme, setTheme] = useState(() => localStorage.getItem("kc_theme") || "light");
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    localStorage.setItem("kc_lang", lang);
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    localStorage.setItem("kc_theme", theme);
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  const loadSettings = useCallback(async () => {
    try {
      const { data } = await api.get("/settings");
      setSettings(data);
    } catch (e) { /* ignore */ }
  }, []);

  useEffect(() => { loadSettings(); }, [loadSettings]);

  const tr = useCallback((key) => (t[lang] && t[lang][key]) || t.en[key] || key, [lang]);
  const toggleLang = () => setLang((l) => (l === "en" ? "te" : "en"));
  const toggleTheme = () => setTheme((th) => (th === "light" ? "dark" : "light"));

  // pick localized field from an object: field_en / field_te
  const pick = useCallback((obj, base) => {
    if (!obj) return "";
    const te = obj[`${base}_te`];
    if (lang === "te" && te) return te;
    return obj[`${base}_en`] || te || "";
  }, [lang]);

  return (
    <AppContext.Provider value={{ lang, setLang, toggleLang, theme, toggleTheme, settings, reloadSettings: loadSettings, tr, pick }}>
      {children}
    </AppContext.Provider>
  );
}
