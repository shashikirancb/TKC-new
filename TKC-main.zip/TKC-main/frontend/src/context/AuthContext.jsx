import { createContext, useContext, useEffect, useState } from "react";
import { api } from "@/lib/api";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null); // null=checking, false=guest, obj=user
  useEffect(() => {
    const token = localStorage.getItem("kc_token");
    if (!token) { setUser(false); return; }
    api.get("/auth/me").then(({ data }) => setUser(data)).catch(() => {
      localStorage.removeItem("kc_token"); setUser(false);
    });
  }, []);

  const login = async (email, password) => {
    const { data } = await api.post("/auth/login", { email, password });
    localStorage.setItem("kc_token", data.access_token);
    setUser(data.user);
    return data.user;
  };
  const logout = () => { localStorage.removeItem("kc_token"); setUser(false); };

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}
