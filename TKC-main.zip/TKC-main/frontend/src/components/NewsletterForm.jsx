import { useState } from "react";
import { useApp } from "@/context/AppContext";
import { api, formatApiError } from "@/lib/api";
import { toast } from "sonner";
import { CheckCircle2, Loader2, Mail } from "lucide-react";

const F = "w-full rounded-[12px] px-4 py-2.5 bg-background border border-border focus:outline-none focus:border-gold text-sm";

export const NewsletterForm = () => {
  const { tr } = useApp();
  const [f, setF] = useState({ email: "", name: "", language: "both", consent: false, honeypot: "" });
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (!f.consent) { toast.error("Please accept the consent."); return; }
    setBusy(true);
    try {
      await api.post("/newsletter/subscribe", f);
      setDone(true);
    } catch (er) {
      toast.error(formatApiError(er.response?.data?.detail));
    } finally { setBusy(false); }
  };

  if (done) return (
    <div className="text-center py-8" data-testid="newsletter-success">
      <CheckCircle2 size={48} className="mx-auto text-teal mb-3" />
      <p className="font-semibold">{tr("news_success")}</p>
    </div>
  );

  return (
    <form onSubmit={submit} className="space-y-3" data-testid="newsletter-form">
      <input type="text" tabIndex={-1} value={f.honeypot} onChange={set("honeypot")} className="hidden" aria-hidden />
      <div className="grid sm:grid-cols-2 gap-3">
        <input className={F} placeholder={tr("email")} type="email" required value={f.email} onChange={set("email")} data-testid="news-email" />
        <input className={F} placeholder={tr("name") + " (optional)"} value={f.name} onChange={set("name")} data-testid="news-name" />
      </div>
      <div className="flex items-center gap-2 text-sm">
        <span className="text-muted-foreground">{tr("lang_pref")}:</span>
        {[["en", "English"], ["te", "తెలుగు"], ["both", tr("both")]].map(([v, l]) => (
          <button type="button" key={v} onClick={() => setF({ ...f, language: v })}
            data-testid={`news-lang-${v}`}
            className={`px-3 py-1 rounded-full text-xs font-semibold border transition-colors ${f.language === v ? "bg-teal text-white border-teal" : "border-border"}`}>{l}</button>
        ))}
      </div>
      <label className="flex items-start gap-2 text-sm cursor-pointer">
        <input type="checkbox" checked={f.consent} onChange={set("consent")} className="mt-1 accent-[#F4B73F]" data-testid="news-consent" />
        <span>{tr("consent_news")}</span>
      </label>
      <button type="submit" disabled={busy} data-testid="news-submit"
        className="w-full bg-gold hover:bg-[#E5A72E] text-midnight font-bold rounded-[14px] px-6 py-3 flex items-center justify-center gap-2 disabled:opacity-60 transition-all hover:scale-[1.01]">
        {busy ? <Loader2 size={18} className="animate-spin" /> : <Mail size={18} />} {tr("subscribe")}
      </button>
    </form>
  );
};
