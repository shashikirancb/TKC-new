import { Link } from "react-router-dom";
import { useState } from "react";
import { Youtube, Instagram, ExternalLink, Send, Lock } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { api, openExternal, formatApiError } from "@/lib/api";
import { LOGO_BANNER_URL, siteImg } from "@/lib/assets";
import { toast } from "sonner";

export const Footer = () => {
  const { tr, pick, settings } = useApp();
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);

  const subscribe = async (e) => {
    e.preventDefault();
    if (!email) return;
    setBusy(true);
    try {
      await api.post("/newsletter/subscribe", { email, consent: true, language: "both" });
      toast.success(tr("news_success"));
      setEmail("");
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail));
    } finally { setBusy(false); }
  };

  const socials = settings?.social_links || [];
  const iconFor = (label) => {
    const l = (label || "").toLowerCase();
    if (l.includes("youtube")) return <Youtube size={18} />;
    if (l.includes("insta")) return <Instagram size={18} />;
    return <ExternalLink size={16} />;
  };

  return (
    <footer className="bg-midnight text-cream mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-14 grid gap-10 md:grid-cols-4">
        <div className="md:col-span-1">
          <img src={siteImg(settings, "logo_footer")} alt="The Kalyan Chronicles" className="w-full max-w-[320px] h-auto object-contain mb-4 drop-shadow-[0_6px_20px_rgba(0,0,0,0.45)]" />
          <p className="text-sm text-cream/70 leading-relaxed">{tr("footer_about")}</p>
          <div className="flex gap-2 mt-4">
            {socials.map((s, i) => (
              <button key={i} onClick={() => openExternal(s.url, s.label?.toLowerCase().includes("youtube") ? "click_youtube" : null, { source: "footer" })}
                className="p-2.5 rounded-full bg-white/10 hover:bg-gold hover:text-midnight transition-colors" data-testid={`footer-social-${i}`} title={s.label}>
                {iconFor(s.label)}
              </button>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-heading font-bold text-gold mb-3">Explore</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/" className="hover:text-gold transition-colors">{tr("nav_home")}</Link></li>
            <li><Link to="/guests" className="hover:text-gold transition-colors">{tr("nav_guests")}</Link></li>
            <li><Link to="/about" className="hover:text-gold transition-colors">{tr("nav_about")}</Link></li>
            <li><Link to="/advertise" className="hover:text-gold transition-colors">{tr("advertise_with_us")}</Link></li>
            <li>
              <button onClick={() => settings?.epaper_url ? openExternal(settings.epaper_url, "click_epaper") : toast.info(tr("coming_soon"))}
                className="hover:text-gold transition-colors flex items-center gap-1" data-testid="footer-epaper-btn">
                {tr("nav_epaper")} <ExternalLink size={12} />
              </button>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-heading font-bold text-gold mb-3">Legal</h4>
          <ul className="space-y-2 text-sm">
            <li><a href="#privacy" className="hover:text-gold transition-colors">{tr("privacy")}</a></li>
            <li><a href="#terms" className="hover:text-gold transition-colors">{tr("terms")}</a></li>
            <li><Link to="/login" className="hover:text-gold transition-colors flex items-center gap-1" data-testid="footer-admin-link"><Lock size={12} /> Admin / CMS</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-heading font-bold text-gold mb-3">{tr("footer_news")}</h4>
          <form onSubmit={subscribe} className="flex gap-2">
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
              placeholder={tr("your_email")} data-testid="footer-newsletter-input"
              className="flex-1 min-w-0 rounded-[12px] px-3 py-2.5 text-sm bg-white/10 border border-white/20 placeholder:text-cream/40 focus:outline-none focus:border-gold" />
            <button type="submit" disabled={busy} data-testid="footer-newsletter-submit"
              className="shrink-0 bg-gold text-midnight rounded-[12px] px-3.5 py-2.5 font-bold disabled:opacity-60">
              <Send size={16} />
            </button>
          </form>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5 text-xs text-cream/60 flex flex-col sm:flex-row justify-between gap-2">
          <span>© {new Date().getFullYear()} {settings?.site_name || "The Kalyan Chronicles"}. {tr("all_rights")}</span>
          <span className="text-gold font-semibold">Inspire &amp; Inform · ప్రేరణ &amp; సమాచారం</span>
        </div>
      </div>
    </footer>
  );
};
