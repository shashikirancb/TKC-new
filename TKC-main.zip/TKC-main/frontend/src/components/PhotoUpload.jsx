import { useState, useCallback, useRef } from "react";
import Cropper from "react-easy-crop";
import { api, formatApiError } from "@/lib/api";
import { getCroppedBlob } from "@/lib/cropImage";
import { Upload, X, Loader2, ImageIcon } from "lucide-react";
import { toast } from "sonner";

export function PhotoUpload({ value, onChange }) {
  const [src, setSrc] = useState(null);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [areaPixels, setAreaPixels] = useState(null);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef(null);

  const onFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Please choose an image"); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("Image must be under 5MB"); return; }
    const reader = new FileReader();
    reader.onload = () => setSrc(reader.result);
    reader.readAsDataURL(file);
  };

  const onCropComplete = useCallback((_, pixels) => setAreaPixels(pixels), []);

  const upload = async () => {
    if (!areaPixels) return;
    setBusy(true);
    try {
      const blob = await getCroppedBlob(src, areaPixels);
      const fd = new FormData();
      fd.append("file", blob, "guest.jpg");
      const { data } = await api.post("/admin/upload-image", fd, { headers: { "Content-Type": "multipart/form-data" } });
      onChange(data.url);
      setSrc(null);
      toast.success("Photo uploaded");
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Upload failed");
    } finally { setBusy(false); }
  };

  return (
    <div>
      <input ref={inputRef} type="file" accept="image/*" onChange={onFile} className="hidden" data-testid="gf-photo-file" />
      {value ? (
        <div className="flex items-center gap-3">
          <img src={value} alt="guest" className="h-16 w-16 rounded-[14px] object-cover border border-border" />
          <button type="button" onClick={() => inputRef.current?.click()} className="text-sm font-semibold text-navy dark:text-gold flex items-center gap-1"><Upload size={15} /> Change photo</button>
          <button type="button" onClick={() => onChange("")} className="text-sm text-destructive">Remove</button>
        </div>
      ) : (
        <button type="button" onClick={() => inputRef.current?.click()} data-testid="gf-photo-upload-btn"
          className="w-full flex items-center justify-center gap-2 rounded-[12px] border-2 border-dashed border-border py-4 text-sm text-muted-foreground hover:border-gold transition-colors">
          <ImageIcon size={18} /> Upload guest photo (optional)
        </button>
      )}

      {src && (
        <div className="fixed inset-0 z-[60] bg-black/70 flex items-center justify-center p-4" onClick={() => !busy && setSrc(null)}>
          <div className="bg-card rounded-[20px] w-full max-w-md p-5" onClick={(e) => e.stopPropagation()} data-testid="crop-modal">
            <div className="flex items-center justify-between mb-3"><h3 className="font-heading font-bold">Crop photo</h3><button onClick={() => setSrc(null)}><X size={20} /></button></div>
            <div className="relative w-full h-72 bg-midnight rounded-[14px] overflow-hidden">
              <Cropper image={src} crop={crop} zoom={zoom} aspect={1} cropShape="rect" showGrid
                onCropChange={setCrop} onZoomChange={setZoom} onCropComplete={onCropComplete} />
            </div>
            <div className="flex items-center gap-3 mt-4">
              <span className="text-xs text-muted-foreground">Zoom</span>
              <input type="range" min={1} max={3} step={0.05} value={zoom} onChange={(e) => setZoom(Number(e.target.value))} className="flex-1 accent-[#F4B73F]" />
            </div>
            <button onClick={upload} disabled={busy} data-testid="crop-save-btn"
              className="mt-4 w-full bg-gold text-midnight font-bold rounded-[14px] py-2.5 flex items-center justify-center gap-2 disabled:opacity-60">
              {busy ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />} Save photo
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
