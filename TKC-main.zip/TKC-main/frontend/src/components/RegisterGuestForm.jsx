import { useState } from "react";
import { useApp } from "@/context/AppContext";
import { api, formatApiError } from "@/lib/api";
import { toast } from "sonner";
import { CheckCircle2, Loader2 } from "lucide-react";

const F = "w-full rounded-[12px] px-4 py-2.5 bg-background border border-border focus:outline-none focus:border-gold text-sm transition-colors";

export const RegisterGuestForm = () => {
  const { tr, settings } = useApp();
  const [f, setF] = useState({ name: "", email: "", phone: "", city: "", profession: "", organisation: "", expertise: "", bio: "", topics: "", links: "", consent: false, honeypot: "" });
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [err, setErr] = useState({});
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const topics = settings?.topics || ["Science", "Health", "Money", "Parenting", "Spirituality", "Society", "Business", "Other"];

  const validate = () => {
    const e = {};
    if (!f.name.trim()) e.name = "Required";
    if (!/^\S+@\S+\.\S+$/.test(f.email)) e.email = "Valid email required";
    if (!f.consent) e.consent = "Please accept";
    if (f.bio.length > 500) e.bio = "Max 500 characters";
    setErr(e); return Object.keys(e).length === 0;
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setBusy(true);
    try {
      await api.post("/applications", f);
      setDone(true);
      toast.success(tr("success"));
    } catch (er) {
      toast.error(formatApiError(er.response?.data?.detail));
    } finally { setBusy(false); }
  };

  if (done) return (
    <div className="text-center py-10" data-testid="register-success">
      <CheckCircle2 size={56} className="mx-auto text-teal mb-4" />
      <p className="text-lg font-semibold">{tr("guest_app_success")}</p>
    </div>
  );

  return (
    <form onSubmit={submit} className="grid sm:grid-cols-2 gap-4" data-testid="register-guest-form">
      <input type="text" tabIndex={-1} autoComplete="off" value={f.honeypot} onChange={set("honeypot")} className="hidden" aria-hidden />
      <div>
        <input className={F} placeholder={tr("name")} value={f.name} onChange={set("name")} data-testid="reg-name" />
        {err.name && <p className="text-xs text-destructive mt-1">{err.name}</p>}
      </div>
      <div>
        <input className={F} placeholder={tr("email")} value={f.email} onChange={set("email")} data-testid="reg-email" />
        {err.email && <p className="text-xs text-destructive mt-1">{err.email}</p>}
      </div>
      <input className={F} placeholder={tr("phone")} value={f.phone} onChange={set("phone")} data-testid="reg-phone" />
      <input className={F} placeholder={tr("city")} value={f.city} onChange={set("city")} data-testid="reg-city" />
      <input className={F} placeholder={tr("profession")} value={f.profession} onChange={set("profession")} data-testid="reg-profession" />
      <input className={F} placeholder={tr("organisation")} value={f.organisation} onChange={set("organisation")} data-testid="reg-org" />
      <select className={F} value={f.expertise} onChange={set("expertise")} data-testid="reg-expertise">
        <option value="">{tr("expertise")}</option>
        {topics.map((t) => <option key={t} value={t}>{t}</option>)}
      </select>
      <input className={F} placeholder={tr("topics")} value={f.topics} onChange={set("topics")} data-testid="reg-topics" />
      <div className="sm:col-span-2">
        <textarea className={F + " min-h-[90px]"} placeholder={tr("bio")} maxLength={500} value={f.bio} onChange={set("bio")} data-testid="reg-bio" />
        <p className="text-xs text-muted-foreground mt-1">{f.bio.length}/500</p>
        {err.bio && <p className="text-xs text-destructive">{err.bio}</p>}
      </div>
      <input className={F + " sm:col-span-2"} placeholder={tr("links")} value={f.links} onChange={set("links")} data-testid="reg-links" />
      <label className="sm:col-span-2 flex items-start gap-2 text-sm cursor-pointer">
        <input type="checkbox" checked={f.consent} onChange={set("consent")} className="mt-1 accent-[#F4B73F]" data-testid="reg-consent" />
        <span>{tr("consent_guest")}{err.consent && <span className="text-destructive"> — {err.consent}</span>}</span>
      </label>
      <button type="submit" disabled={busy} data-testid="reg-submit"
        className="sm:col-span-2 bg-gold hover:bg-[#E5A72E] text-midnight font-bold rounded-[14px] px-6 py-3 flex items-center justify-center gap-2 disabled:opacity-60 transition-all hover:scale-[1.01]">
        {busy && <Loader2 size={18} className="animate-spin" />} {tr("submit")}
      </button>
    </form>
  );
};
