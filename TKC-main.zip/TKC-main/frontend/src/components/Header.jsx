import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import { Menu, X, Moon, Sun, Youtube, ExternalLink, Globe } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { openExternal } from "@/lib/api";
import { LOGO_BANNER_URL, siteImg } from "@/lib/assets";

export const Header = () => {
  const { tr, lang, toggleLang, theme, toggleTheme, settings } = useApp();
  const [open, setOpen] = useState(false);
  const [hidden, setHidden] = useState(false);
  const lastY = useRef(0);
  const navigate = useNavigate();
  const yt = settings?.youtube_channel_url;
  const epaper = settings?.epaper_url;

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      if (open) { setHidden(false); lastY.current = y; return; }
      if (y < 80) { setHidden(false); }
      else if (y > lastY.current + 6) { setHidden(true); }
      else if (y < lastY.current - 6) { setHidden(false); }
      lastY.current = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [open]);

  const navItems = [
    { to: "/", label: tr("nav_home") },
    { to: "/guests", label: tr("nav_guests") },
    { to: "/about", label: tr("nav_about") },
    { to: "/advertise", label: tr("nav_advertise") },
  ];

  const handleEpaper = () => {
    if (epaper) openExternal(epaper, "click_epaper");
    setOpen(false);
  };

  return (
    <header className={`sticky top-0 z-50 backdrop-blur-xl bg-cream/85 dark:bg-midnight/90 border-b border-border transition-transform duration-300 ease-out ${hidden ? "-translate-y-full" : "translate-y-0"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-20 lg:h-24">
        <Link to="/" className="flex items-center shrink-0 group" data-testid="header-logo-link">
          <img src={siteImg(settings, "logo_header")} alt="The Kalyan Chronicles logo"
            className="h-14 sm:h-16 lg:h-[72px] w-auto object-contain transition-transform duration-300 group-hover:scale-[1.04] drop-shadow-[0_3px_10px_rgba(10,31,68,0.2)] dark:drop-shadow-[0_3px_12px_rgba(0,0,0,0.5)]" />
        </Link>

        <nav className="hidden lg:flex items-center gap-7 absolute left-1/2 -translate-x-1/2">
          {navItems.map((n) => (
            <Link key={n.to} to={n.to} data-testid={`nav-${n.to.replace("/", "") || "home"}`}
              className="relative text-[15px] font-semibold text-foreground/80 hover:text-foreground transition-colors after:absolute after:-bottom-1.5 after:left-0 after:h-0.5 after:w-0 hover:after:w-full after:bg-gold after:transition-all after:duration-300">
              {n.label}
            </Link>
          ))}
          <button onClick={handleEpaper} data-testid="nav-epaper"
            className="relative text-[15px] font-semibold text-foreground/80 hover:text-foreground transition-colors flex items-center gap-1 after:absolute after:-bottom-1.5 after:left-0 after:h-0.5 after:w-0 hover:after:w-full after:bg-gold after:transition-all after:duration-300">
            {tr("nav_epaper")} <ExternalLink size={13} />
          </button>
        </nav>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <button onClick={toggleLang} data-testid="language-toggle-btn"
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold rounded-full border border-border hover:border-gold transition-colors"
            title="Switch language">
            <Globe size={13} />
            <span className={lang === "en" ? "text-gold" : "opacity-60"}>EN</span>
            <span className="opacity-30">|</span>
            <span className={lang === "te" ? "text-gold" : "opacity-60"}>తెలుగు</span>
          </button>
          <button onClick={toggleTheme} data-testid="theme-toggle-btn"
            className="p-2 rounded-full border border-border hover:border-gold transition-colors">
            {theme === "light" ? <Moon size={16} /> : <Sun size={16} />}
          </button>
          <button onClick={() => openExternal(yt, "click_youtube", { source: "header" })}
            data-testid="header-watch-youtube-btn"
            className="hidden sm:flex items-center gap-2 bg-gold hover:bg-[#E5A72E] text-midnight font-bold rounded-[14px] px-4 py-2.5 text-sm transition-all hover:scale-[1.02] shadow-[0_4px_20px_rgba(244,183,63,0.3)]">
            <Youtube size={17} /> <span className="hidden md:inline">{tr("watch_youtube")}</span>
          </button>
          <button onClick={() => setOpen(!open)} className="lg:hidden p-2 rounded-full border border-border" data-testid="mobile-menu-btn">
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden border-t border-border bg-cream dark:bg-midnight px-4 py-3 space-y-1 anim-float">
          {navItems.map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)}
              className="block px-4 py-3 rounded-[14px] font-semibold hover:bg-navy/10 dark:hover:bg-white/10" data-testid={`mobile-nav-${n.to.replace("/", "") || "home"}`}>
              {n.label}
            </Link>
          ))}
          <button onClick={handleEpaper} className="w-full text-left px-4 py-3 rounded-[14px] font-semibold hover:bg-navy/10 dark:hover:bg-white/10 flex items-center gap-1">
            {tr("nav_epaper")} <ExternalLink size={13} />
          </button>
          <button onClick={() => { openExternal(yt, "click_youtube", { source: "mobile" }); setOpen(false); }}
            className="w-full flex items-center justify-center gap-2 bg-gold text-midnight font-bold rounded-[14px] px-4 py-3 mt-2">
            <Youtube size={18} /> {tr("watch_youtube")}
          </button>
        </div>
      )}
    </header>
  );
};
