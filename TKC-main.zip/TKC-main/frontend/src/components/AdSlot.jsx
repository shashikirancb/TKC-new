import { useEffect, useState, useRef } from "react";
import { api, openExternal } from "@/lib/api";
import { useApp } from "@/context/AppContext";
import { AD_SPECS } from "@/lib/adSpecs";

export const AdSlot = ({ slot, className = "" }) => {
  const { lang, tr } = useApp();
  const [ad, setAd] = useState(null);
  const seen = useRef(false);

  useEffect(() => {
    let active = true;
    api.get(`/ads/${slot}?lang=${lang}`).then(({ data }) => { if (active) setAd(data); }).catch(() => {});
    return () => { active = false; };
  }, [slot, lang]);

  useEffect(() => {
    if (ad && ad.id && !seen.current) {
      seen.current = true;
      api.post(`/ads/${ad.id}/impression`).catch(() => {});
    }
  }, [ad]);

  if (!ad) return null;
  const spec = AD_SPECS[slot];

  const handleClick = () => {
    api.post(`/ads/${ad.id}/click`).catch(() => {});
    if (ad.destination_url) window.open(ad.destination_url, "_blank", "noopener,sponsored");
  };

  if (ad.embed_enabled && ad.embed_code) {
    return (
      <div className={`relative ${className}`} data-testid={`ad-slot-${slot}`}>
        <span className="absolute top-2 left-2 z-10 bg-signal text-midnight text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full">{tr("sponsored")}</span>
        <div dangerouslySetInnerHTML={{ __html: ad.embed_code }} />
      </div>
    );
  }

  return (
    <button onClick={handleClick} data-testid={`ad-slot-${slot}`} style={{ aspectRatio: spec?.aspect }}
      className={`group relative w-full overflow-hidden rounded-[16px] border-2 border-dashed border-gold/50 block text-left ${className}`}>
      <span className="absolute top-2 left-2 z-10 bg-signal text-midnight text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full shadow">{tr("sponsored")}</span>
      {ad.image_url && (
        <img src={ad.image_url} alt={ad.headline || ad.advertiser} loading="lazy"
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-500" />
      )}
      {ad.headline && (
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-midnight/90 to-transparent px-4 py-3">
          <p className="text-white font-semibold text-sm">{ad.headline}</p>
          <p className="text-cream/70 text-xs">{ad.advertiser}</p>
        </div>
      )}
    </button>
  );
};
