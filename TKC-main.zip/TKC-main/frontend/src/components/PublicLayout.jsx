import { useState } from "react";
import { useApp } from "@/context/AppContext";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const CookieNotice = () => {
  const { tr } = useApp();
  const [show, setShow] = useState(() => !localStorage.getItem("kc_cookie_ok"));
  if (!show) return null;
  return (
    <div className="fixed bottom-4 inset-x-4 sm:left-auto sm:right-4 sm:max-w-sm z-50 bg-card border border-border rounded-[20px] shadow-xl p-5 anim-float" data-testid="cookie-notice">
      <p className="text-sm text-muted-foreground">{tr("cookie_text")}</p>
      <button onClick={() => { localStorage.setItem("kc_cookie_ok", "1"); setShow(false); }}
        data-testid="cookie-accept-btn"
        className="mt-3 bg-navy text-white text-sm font-semibold rounded-[14px] px-5 py-2 w-full">{tr("accept")}</button>
    </div>
  );
};

export const PublicLayout = ({ children }) => {
  const { lang } = useApp();
  return (
    <div className={lang === "te" ? "lang-te" : ""}>
      <Header />
      <main>{children}</main>
      <Footer />
      <CookieNotice />
    </div>
  );
};
