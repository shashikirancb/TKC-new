import { useRef, useState } from "react";
import { api } from "@/lib/api";
import { Upload, Loader2, RotateCcw } from "lucide-react";
import { toast } from "sonner";

const F = "w-full rounded-[10px] px-3 py-1.5 bg-background border border-border focus:outline-none focus:border-gold text-xs";

export function ImageField({ label, value, defaultSrc, onChange }) {
  const [busy, setBusy] = useState(false);
  const inputRef = useRef();
  const preview = value || defaultSrc;

  const upload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Please choose an image file"); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("Image must be under 5MB"); return; }
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const { data } = await api.post("/admin/upload-image", fd, { headers: { "Content-Type": "multipart/form-data" } });
      onChange(data.url);
      toast.success("Image uploaded");
    } catch (er) { toast.error("Upload failed"); }
    finally { setBusy(false); if (inputRef.current) inputRef.current.value = ""; }
  };

  return (
    <div className="flex gap-3 items-start py-2 border-b border-border last:border-0" data-testid={`imgfield-${label}`}>
      <div className="w-28 h-20 rounded-[12px] overflow-hidden bg-background border border-border shrink-0">
        {preview && <img src={preview} alt={label} className="w-full h-full object-cover" />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-semibold mb-1">{label}</div>
        <input className={F} placeholder="Paste image URL or upload" value={value || ""} onChange={(e) => onChange(e.target.value)} />
        <div className="flex gap-2 mt-1.5">
          <button type="button" onClick={() => inputRef.current?.click()} disabled={busy}
            className="flex items-center gap-1 bg-navy text-white rounded-[10px] px-3 py-1.5 text-xs font-semibold disabled:opacity-60">
            {busy ? <Loader2 size={13} className="animate-spin" /> : <Upload size={13} />} Upload
          </button>
          {value && (
            <button type="button" onClick={() => onChange("")}
              className="flex items-center gap-1 text-muted-foreground hover:text-foreground rounded-[10px] px-2 py-1.5 text-xs font-semibold">
              <RotateCcw size={13} /> Reset to default
            </button>
          )}
        </div>
        <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={upload} />
      </div>
    </div>
  );
}
