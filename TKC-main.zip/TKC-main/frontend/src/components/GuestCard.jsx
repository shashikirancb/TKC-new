import { Link } from "react-router-dom";
import { Play, Calendar } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { openExternal } from "@/lib/api";

export const GuestCard = ({ guest, index = 0 }) => {
  const { lang, tr } = useApp();
  const title = (lang === "te" && guest.title_te) ? guest.title_te : (guest.title_en || guest.name);
  const synopsis = (lang === "te" && guest.synopsis_te) ? guest.synopsis_te : guest.synopsis_en;
  const img = guest.thumbnail || guest.yt_thumbnail;

  return (
    <div data-testid={`guest-card-${guest.slug}`}
      className="group rounded-[20px] bg-card border border-border shadow-[0_12px_32px_rgba(15,47,99,0.08)] dark:shadow-[0_12px_32px_rgba(0,0,0,0.4)] hover:-translate-y-1 transition-all duration-300 flex flex-col overflow-hidden anim-float"
      style={{ animationDelay: `${index * 60}ms` }}>
      <Link to={`/guests/${guest.slug}`} className="relative block aspect-video overflow-hidden bg-midnight">
        {img && <img src={img} alt={guest.name} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />}
        <span className="absolute top-3 right-3 bg-teal/90 text-white text-xs font-semibold px-2.5 py-0.5 rounded-full">{guest.topic}</span>
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-midnight/30">
          <div className="h-12 w-12 rounded-full bg-gold flex items-center justify-center"><Play size={20} className="text-midnight ml-0.5" fill="currentColor" /></div>
        </div>
      </Link>
      <div className={`p-5 flex flex-col flex-1 ${lang === "te" ? "lang-te" : ""}`}>
        <Link to={`/guests/${guest.slug}`}>
          <h3 className="font-heading font-bold text-lg leading-snug line-clamp-2 hover:text-navy dark:hover:text-gold transition-colors">{title}</h3>
        </Link>
        <p className="text-sm font-semibold text-teal mt-1">{guest.name}</p>
        <p className="text-xs text-muted-foreground">{guest.designation}</p>
        {synopsis && <p className="text-sm text-muted-foreground mt-2 line-clamp-2 flex-1">{synopsis}</p>}
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
          <span className="text-xs text-muted-foreground flex items-center gap-1"><Calendar size={12} />{guest.episode_date}</span>
          <button onClick={() => openExternal(guest.youtube_url, "click_youtube", { video_id: guest.video_id })}
            data-testid={`guest-card-watch-${guest.slug}`}
            className="flex items-center gap-1.5 bg-gold hover:bg-[#E5A72E] text-midnight text-sm font-bold rounded-[14px] px-3.5 py-1.5 transition-all hover:scale-[1.03]">
            <Play size={14} fill="currentColor" /> {tr("watch")}
          </button>
        </div>
      </div>
    </div>
  );
};
