import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppProvider } from "@/context/AppContext";
import { AuthProvider } from "@/context/AuthContext";
import { Toaster } from "@/components/ui/sonner";
import Home from "@/pages/Home";
import Guests from "@/pages/Guests";
import GuestDetail from "@/pages/GuestDetail";
import Advertise from "@/pages/Advertise";
import About from "@/pages/About";
import AdminLogin from "@/pages/admin/AdminLogin";
import Admin from "@/pages/admin/Admin";

function App() {
  return (
    <div className="App">
      <AppProvider>
        <AuthProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/guests" element={<Guests />} />
              <Route path="/guests/:slug" element={<GuestDetail />} />
              <Route path="/advertise" element={<Advertise />} />
              <Route path="/about" element={<About />} />
              <Route path="/login" element={<AdminLogin />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/admin/:section" element={<Admin />} />
            </Routes>
          </BrowserRouter>
          <Toaster position="top-center" richColors />
        </AuthProvider>
      </AppProvider>
    </div>
  );
}

export default App;
